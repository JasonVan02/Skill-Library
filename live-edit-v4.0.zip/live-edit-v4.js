(function(){
'use strict';

/* ═══════════════════════ CONFIG ═══════════════════════ */
const HL_COLOR = '#FFF176';
const BRAND    = '#7C48DB';
const Z        = 999999;
const LE_TAG   = 'data-le-v3';   // 标识live-edit注入的script

/* ═══════════════════════ STATE ═══════════════════════ */
const S = {
  open: false,
  editing: false,
  dragMode: false,
  imgMode: false,
  activeEl: null,
  editedEls: new Set(),
  structEdits: 0,
  dragState: null,
  handles: [],
  dragContexts: [],
  fontBadgeTimer: null,
  changeLog: [],
  textSnaps: new Map(),
  delMode: false,
  addMode: false,
  undoStack: [],
  delUnit: null,
  delArmed: false
};

/* ═══════════════════════ STYLES ═══════════════════════ */
const styleEl = document.createElement('style');
styleEl.textContent = `
/* ── 编辑按钮 & 工具栏 ── */
.le-root{position:fixed;top:24px;right:24px;z-index:${Z};font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;line-height:1.4}
.le-box{height:44px;background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.12);overflow:hidden;display:flex;align-items:center;max-width:44px;transition:max-width .4s cubic-bezier(.16,1,.3,1),box-shadow .3s;cursor:pointer;user-select:none;position:relative}
.le-box.le-open{max-width:860px;cursor:default;box-shadow:0 6px 28px rgba(0,0,0,.16);overflow:visible}

/* 编辑图标 */
.le-icon-w{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:20px;transition:opacity .15s}
.le-box.le-open .le-icon-w{opacity:0;pointer-events:none}
@keyframes le-write{0%,100%{transform:rotate(0)}20%{transform:rotate(-14deg)}40%{transform:rotate(14deg)}60%{transform:rotate(-10deg)}80%{transform:rotate(10deg)}}
.le-box:not(.le-open):hover .le-icon-w{animation:le-write .55s ease-in-out}

/* 悬浮提示 */
.le-tip-main{position:absolute;top:calc(100% + 8px);left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:6px 14px;border-radius:6px;font-size:13px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .2s}
.le-tip-main::after{content:'';position:absolute;bottom:100%;left:50%;transform:translateX(-50%);border:5px solid transparent;border-bottom-color:#333}
.le-box:not(.le-open):hover .le-tip-main{opacity:1}

/* 工具栏内部 */
.le-bar{display:flex;align-items:center;height:100%;padding:0 8px;gap:3px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .15s}
.le-box.le-open .le-bar{opacity:1;pointer-events:auto;transition:opacity .25s .15s}

/* 状态 */
.le-status{position:relative;display:flex;align-items:center;gap:6px;padding:0 6px 0 4px;font-size:12px;color:#999;min-width:50px;flex-shrink:0;cursor:default}
.le-dot{width:7px;height:7px;border-radius:50%;background:#22C55E;flex-shrink:0}
@keyframes le-pulse{0%,100%{box-shadow:0 0 0 0 rgba(34,197,94,.4)}50%{box-shadow:0 0 0 4px rgba(34,197,94,0)}}
.le-dot.le-has{animation:le-pulse 2s infinite}

/* 分隔符 */
.le-sep{width:1px;height:20px;background:#E8E8E8;flex-shrink:0;margin:0 3px}

/* 工具按钮 */
.le-tb{position:relative;height:28px;border:none;background:transparent;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:4px;color:#666;font-size:12px;transition:background .15s,color .15s;flex-shrink:0;outline:none;padding:0 8px;font-family:inherit;white-space:nowrap}
.le-tb:hover{background:#F0F0F0;color:#333}
.le-tb.le-on{background:#F0E6FF;color:${BRAND}}
.le-tb svg{width:13px;height:13px;fill:currentColor;pointer-events:none}

/* 工具按钮提示 */
.le-tt{position:absolute;top:calc(100% + 10px);left:50%;transform:translateX(-50%);background:#333;color:#fff;font-size:11px;padding:3px 9px;border-radius:4px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .15s;z-index:${Z+4}}
.le-tt::after{content:'';position:absolute;bottom:100%;left:50%;transform:translateX(-50%);border:4px solid transparent;border-bottom-color:#333}
.le-tb:hover>.le-tt,.le-save:hover>.le-tt,.le-close:hover>.le-tt,.le-status:hover>.le-tt,.le-dh:hover>.le-tt,.le-hr:hover>.le-tt{opacity:1}

/* 保存按钮 */
.le-save{position:relative;height:26px;border:none;background:#333;color:#fff;border-radius:6px;padding:0 12px;font-size:12px;cursor:pointer;transition:background .15s;flex-shrink:0;font-family:inherit;line-height:26px}
.le-save:hover{background:#555}

/* 关闭按钮 */
.le-close{position:relative;width:30px;height:30px;border:none;background:transparent;border-radius:7px;cursor:pointer;font-size:16px;color:#BBB;display:flex;align-items:center;justify-content:center;transition:color .15s,background .15s;flex-shrink:0;line-height:1}
.le-close:hover{color:#666;background:#F0F0F0}

/* ── 编辑态文字指示 ── */
.le-editable{transition:outline .15s;cursor:text!important;outline:2px solid transparent!important;border-radius:2px}
.le-editable:hover{outline-color:rgba(124,72,219,.18)!important}
.le-editable:focus{outline-color:rgba(124,72,219,.45)!important;outline-offset:2px}

/* ── 字号浮标 ── */
.le-fbadge{position:fixed;background:#333;color:#fff;font-size:11px;padding:2px 8px;border-radius:4px;pointer-events:none;opacity:0;transition:opacity .18s,transform .18s;z-index:${Z+2};font-family:'SF Mono',Menlo,monospace;letter-spacing:.3px;transform:translateY(2px)}
.le-fbadge.le-show{opacity:1;transform:translateY(0)}

/* ── 换色面板（多段式） ── */
.le-cp{position:absolute;top:calc(100% + 8px);left:50%;transform:translateX(-50%);background:#fff;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.14),0 2px 8px rgba(0,0,0,.06);padding:14px 16px;width:260px;opacity:0;pointer-events:none;transition:opacity .18s;z-index:${Z+5}}
.le-cp.le-show{opacity:1;pointer-events:auto}
.le-cp::before{content:'';position:absolute;bottom:100%;left:50%;transform:translateX(-50%);border:6px solid transparent;border-bottom-color:#fff}
.le-cs-h{font-size:10px;color:#AAA;margin:0 0 7px;letter-spacing:.8px;font-weight:600}
.le-cs-sep{height:1px;background:#F0F0F0;margin:10px 0}
.le-cs-row{display:flex;gap:7px;flex-wrap:wrap;align-items:center}
.le-cd{width:24px;height:24px;border-radius:50%;cursor:pointer;border:2.5px solid transparent;transition:all .15s;flex-shrink:0}
.le-cd:hover{transform:scale(1.18);border-color:rgba(0,0,0,.1);box-shadow:0 2px 8px rgba(0,0,0,.12)}
.le-cpk-w{position:relative;width:24px;height:24px;flex-shrink:0;cursor:pointer;border-radius:50%;border:2px dashed #D0D0D0;display:flex;align-items:center;justify-content:center;transition:all .15s;background:#FAFAFA}
.le-cpk-w:hover{transform:scale(1.18);border-color:#999;background:#F0F0F0}
.le-cpk-w svg{width:10px;height:10px;pointer-events:none}
.le-cpk{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;border:none;padding:0}
.le-hex-row{display:flex;gap:6px;align-items:center}
.le-hex-in{flex:1;height:28px;border:1.5px solid #E5E5E5;border-radius:7px;padding:0 8px;font-size:12px;font-family:'SF Mono',Menlo,'Courier New',monospace;outline:none;color:#333;transition:border-color .2s;background:#FAFAFA}
.le-hex-in:focus{border-color:${BRAND};background:#fff}
.le-hex-in::placeholder{color:#CCC}
.le-eye-btn{height:28px;border:1.5px solid #E5E5E5;border-radius:7px;padding:0 8px;background:#FAFAFA;cursor:pointer;display:flex;align-items:center;gap:3px;font-size:11px;color:#888;transition:all .15s;font-family:inherit;white-space:nowrap;flex-shrink:0}
.le-eye-btn:hover{background:#F0F0F0;border-color:#CCC;color:#555}
.le-eye-btn svg{width:13px;height:13px;fill:currentColor;flex-shrink:0}
.le-pp-empty{font-size:11px;color:#CCC;padding:2px 0}

/* ── 文字样式面板 ── */
.le-sp{position:absolute;top:calc(100% + 8px);left:50%;transform:translateX(-50%);background:#fff;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.14),0 2px 8px rgba(0,0,0,.06);padding:10px;width:290px;max-height:340px;overflow-y:auto;opacity:0;pointer-events:none;transition:opacity .18s;z-index:${Z+5}}
.le-sp.le-show{opacity:1;pointer-events:auto}
.le-sp::before{content:'';position:absolute;bottom:100%;left:50%;transform:translateX(-50%);border:6px solid transparent;border-bottom-color:#fff}
.le-sp::-webkit-scrollbar{width:3px}
.le-sp::-webkit-scrollbar-thumb{background:#E0E0E0;border-radius:2px}
.le-si{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;transition:background .12s}
.le-si:hover{background:#F5F3FF}
.le-si-preview{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit;line-height:1.3}
.le-si-meta{font-size:10px;color:#BBB;white-space:nowrap;flex-shrink:0;font-family:'SF Mono',Menlo,monospace}
.le-si+.le-si{border-top:1px solid #F5F5F5}

/* ── 高亮 ── */
.le-hl{background:${HL_COLOR}!important;border-radius:2px;padding:0 1px;transition:background .2s}

/* ── 分割线 ── */
.le-hr{position:relative;height:1px;margin:20px 0;opacity:0;transition:opacity .35s,height .15s;cursor:default}
.le-hr::before{content:'';position:absolute;inset:0;background:#D5D5D5;transition:background .15s}
.le-hr.le-vis{opacity:1}
.le-hr:hover{height:3px;cursor:pointer}
.le-hr:hover::before{background:${BRAND}66}

/* ── 拖拽模式 ── */
.le-draggable{position:relative!important;transition:outline-color .2s}
.le-drag-on{outline:2px dashed rgba(124,72,219,.22)!important;outline-offset:4px;border-radius:4px}
.le-dh{position:absolute;top:6px;left:6px;width:22px;height:20px;background:rgba(255,255,255,.95);border:1px solid #DDD;border-radius:5px;cursor:grab;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .18s;z-index:${Z-1};box-shadow:0 1px 3px rgba(0,0,0,.06)}
.le-draggable:hover>.le-dh{opacity:1}
.le-dh:active{cursor:grabbing}
.le-dh-dots{display:grid;grid-template-columns:3px 3px;gap:2.5px 3.5px}
.le-dh-dots i{width:3px;height:3px;border-radius:50%;background:#BBB;display:block;font-style:normal}
.le-ghost{position:fixed!important;z-index:${Z+1}!important;opacity:.7;box-shadow:0 12px 36px rgba(0,0,0,.18)!important;pointer-events:none!important;transform:scale(1.02) rotate(.5deg);border-radius:8px;overflow:hidden}
.le-ph{background:rgba(124,72,219,.06);border:2px dashed ${BRAND}44;border-radius:8px;transition:height .15s ease-out;min-height:8px}

/* ── Toast ── */
.le-toast{position:fixed;top:28px;left:50%;transform:translateX(-50%) translateY(-16px);background:#333;color:#fff;padding:10px 24px;border-radius:8px;font-size:14px;opacity:0;transition:opacity .3s,transform .3s;z-index:${Z+3};pointer-events:none;white-space:nowrap}
.le-toast.le-show{opacity:1;transform:translateX(-50%) translateY(0)}

/* ── 编辑记录弹窗 ── */
.le-mbg{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:${Z+10};display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .25s}
.le-mbg.le-show{opacity:1}
.le-md{background:#fff;border-radius:16px;width:700px;max-width:92vw;max-height:82vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25);transform:translateY(12px) scale(.97);transition:transform .3s cubic-bezier(.16,1,.3,1);overflow:hidden}
.le-mbg.le-show .le-md{transform:translateY(0) scale(1)}
.le-md-hd{padding:20px 24px 14px;display:flex;align-items:flex-start;justify-content:space-between;flex-shrink:0}
.le-md-hd-l h3{font-size:15px;font-weight:700;color:#1A1A1A;margin:0;line-height:1.3}
.le-md-hd-l p{font-size:11px;color:#999;margin:4px 0 0;line-height:1}
.le-md-hd-r{display:flex;gap:8px;flex-shrink:0;padding-top:0}
.le-md-copy{height:28px;padding:0 14px;background:#333;color:#fff;border:none;border-radius:7px;font-size:12px;cursor:pointer;font-family:inherit;transition:background .2s;font-weight:500}
.le-md-copy:hover{background:#555}
.le-md-copy.le-copied{background:#22C55E;pointer-events:none}
.le-md-cls{height:28px;padding:0 12px;background:#F3F3F3;color:#666;border:none;border-radius:7px;font-size:12px;cursor:pointer;font-family:inherit;transition:background .15s}
.le-md-cls:hover{background:#E8E8E8;color:#333}
.le-md-body{flex:1;overflow-y:auto;padding:0 24px 6px}
.le-md-body::-webkit-scrollbar{width:3px}
.le-md-body::-webkit-scrollbar-thumb{background:#E5E5E5;border-radius:2px}
.le-chg{border:1px solid #F0EFF0;border-radius:10px;padding:14px 18px;margin-bottom:12px;background:#FCFCFC}
.le-chg-hd{font-size:11px;color:#999;margin-bottom:10px;line-height:1}
.le-chg-diff{display:flex;align-items:flex-start;gap:12px}
.le-chg-old{flex:1;background:#FFF0F0;border-radius:6px;padding:10px 12px;font-size:12px;color:#666;line-height:1.7;text-decoration:line-through;text-decoration-color:#BBB}
.le-chg-arr{color:#CCC;font-size:14px;flex-shrink:0;padding-top:8px;line-height:1}
.le-chg-new{flex:1;background:#F4FFED;border-radius:6px;padding:10px 12px;font-size:12px;color:#1A1A1A;line-height:1.7}
.le-chg-desc{font-size:12px;color:#555;line-height:1.7;padding:2px 0}
.le-md-ft{padding:10px 24px 18px;font-size:11px;color:#AAA;flex-shrink:0}

/* ── v3.1 图片替换面板 ── */
.le-img-panel{position:fixed;z-index:${Z+5};background:#fff;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,.18);padding:10px;width:196px;font-size:12px;opacity:0;pointer-events:none;transform:translateY(6px);transition:opacity .2s,transform .2s}
.le-img-panel.le-show{opacity:1;pointer-events:auto;transform:translateY(0)}
.le-ip-hd{font-size:11px;color:#999;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between}
.le-ip-x{border:none;background:none;cursor:pointer;color:#BBB;font-size:14px;line-height:1;padding:0 2px}
.le-ip-x:hover{color:#666}
.le-ip-btn{display:flex;align-items:center;gap:6px;width:100%;border:1px solid #E8E8E8;background:#FAFAFA;border-radius:6px;padding:7px 10px;cursor:pointer;font-size:12px;color:#555;margin-bottom:6px;transition:background .15s,border-color .15s;font-family:inherit}
.le-ip-btn:hover{background:#F0E6FF;border-color:${BRAND};color:${BRAND}}
.le-ip-url{width:100%;border:1px solid #E8E8E8;border-radius:6px;padding:6px 8px;font-size:11px;outline:none;box-sizing:border-box;font-family:inherit}
.le-ip-url:focus{border-color:${BRAND}}
.le-ip-tip{font-size:10px;color:#CCC;margin-top:4px}

/* ── v3.1 间距调整面板 ── */
.le-spc{position:absolute;top:calc(100% + 8px);right:0;background:#fff;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,.16);padding:12px 14px;width:236px;display:none;z-index:10}
.le-spc.le-show{display:block}
.le-spc-hd{font-size:11px;color:#999;margin-bottom:8px}
.le-spc-empty{padding:14px 0;text-align:center;color:#CCC;font-size:12px}
.le-spc-row{display:flex;align-items:center;gap:6px;margin-bottom:6px}
.le-spc-lb{width:52px;font-size:11px;color:#888;flex-shrink:0}
.le-spc-btn{width:24px;height:24px;border:1px solid #E8E8E8;background:#FAFAFA;border-radius:5px;cursor:pointer;font-size:13px;color:#666;display:flex;align-items:center;justify-content:center;transition:background .12s,border-color .12s;flex-shrink:0;font-family:inherit;padding:0}
.le-spc-btn:hover{background:#F0E6FF;border-color:${BRAND};color:${BRAND}}
.le-spc-val{flex:1;text-align:center;font-size:12px;color:#333;font-weight:600;font-variant-numeric:tabular-nums}
.le-spc-sep{height:1px;background:#F0F0F0;margin:8px 0}
.le-spc-ft{font-size:10px;color:#CCC;margin-top:6px}
.le-spc-hint{outline:2px dashed ${BRAND}!important;outline-offset:2px}

/* ── v3.3 删除角标 / 模式互斥 / 撤回 / 全局校准弹窗 ── */
body.le-delmode{cursor:crosshair}
body.le-delmode .le-del-unit{outline:2px solid #FF4D4F!important;outline-offset:2px}
body.le-delmode .le-del-unit.le-armed{outline:3px solid #FF4D4F!important;outline-offset:2px;background:rgba(255,77,79,.06)!important}
body.le-addmode .le-add-unit{outline:2px dashed #52C41A!important;outline-offset:2px;cursor:copy}
.le-undo{margin-left:6px;background:#fff;border:1px solid #E8E8E8;border-radius:6px;padding:2px 10px;font-size:11px;color:#666;cursor:pointer;font-family:inherit;white-space:nowrap}
.le-undo:hover{color:${BRAND};border-color:${BRAND}}
.le-undo[disabled]{opacity:.4;cursor:not-allowed}
.le-addpop{position:fixed;z-index:999998;background:#fff;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.18);padding:8px;display:none;gap:6px}
.le-addpop.le-show{display:flex}
.le-addpop button{width:30px;height:30px;border-radius:6px;border:1px solid #E8E8E8;background:#fff;font-size:14px;cursor:pointer;color:#666}
.le-addpop button:hover{border-color:#52C41A;color:#52C41A}
.le-addpop button.le-rec{border-color:#52C41A;color:#52C41A;font-weight:700}
.le-addpop .le-ap-tip{position:absolute;top:-20px;left:0;font-size:10px;color:#52C41A;white-space:nowrap}
.le-gs{position:fixed;left:50%;top:16%;transform:translateX(-50%);background:#fff;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.22);padding:14px 16px;width:320px;z-index:99999;font-family:inherit}
.le-gs-hd{font-size:13px;font-weight:700;color:#333;margin-bottom:8px}
.le-gs-bd{font-size:12px;color:#666;line-height:1.7;margin-bottom:12px}
.le-gs-bd b{color:${BRAND}}
.le-gs-ft{display:flex;gap:8px;justify-content:flex-end}
.le-gs-yes{background:${BRAND};color:#fff;border:none;border-radius:6px;padding:6px 12px;font-size:12px;cursor:pointer;font-family:inherit}
.le-gs-yes:hover{opacity:.9}
.le-gs-no{background:#fff;color:#666;border:1px solid #E8E8E8;border-radius:6px;padding:6px 12px;font-size:12px;cursor:pointer;font-family:inherit}
.le-gs-no:hover{border-color:#BBB}

/* ── v4.0 直接操纵：悬停操作条 ── */
.le-hb{position:fixed;z-index:${Z+5};display:flex;align-items:center;gap:2px;background:rgba(255,255,255,.97);border:1px solid #E4E2E8;border-radius:8px;padding:3px;box-shadow:0 4px 16px rgba(0,0,0,.18);opacity:0;pointer-events:none;transition:opacity .12s;isolation:isolate}
.le-hb.le-show{opacity:1;pointer-events:auto}
.le-hb button{width:26px;height:26px;border:none;background:transparent;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#555;padding:0;font-family:inherit;position:relative}
.le-hb button:hover{background:#F0E6FF;color:${BRAND}}
.le-hb button.le-hb-del:hover{background:#FFF1F0;color:#FF4D4F}
.le-hb button.le-armed{background:#FFF1F0;color:#FF4D4F}
.le-hb .le-tt{position:absolute;top:calc(100% + 6px);left:50%;transform:translateX(-50%);background:#333;color:#fff;font-size:10px;padding:3px 8px;border-radius:4px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .15s;z-index:1}
.le-hb button:hover .le-tt{opacity:1}
.le-hb-unit{outline:1.5px dashed rgba(124,72,219,.5)!important;outline-offset:2px;border-radius:4px}
`;
document.head.appendChild(styleEl);

/* ═══════════════════════ HELPERS ═══════════════════════ */
function mk(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}
function btn(id, ico, tip, fn) {
  const b = mk('button','le-tb');
  b.dataset.tool = id;
  b.innerHTML = ico + '<span class="le-tt">' + tip + '</span>';
  b.addEventListener('click', function(e) { e.stopPropagation(); fn(e); });
  return b;
}
function toast(msg) {
  const t = mk('div','le-toast', msg);
  document.body.appendChild(t);
  requestAnimationFrame(function() {
    requestAnimationFrame(function() { t.classList.add('le-show'); });
  });
  setTimeout(function() {
    t.classList.remove('le-show');
    setTimeout(function() { t.remove(); }, 350);
  }, 2200);
}
function isLE(el) {
  return el && (el.closest('.le-root') || el.closest('.le-fbadge') || el.closest('.le-toast') || el.closest('.le-dh') || el.closest('.le-gs') || el.closest('.le-addpop') || el.closest('.le-hb'));
}
function elLabel(el) {
  var t = (el && el.textContent || '').trim().replace(/\s+/g,' ');
  return t.length > 25 ? t.substring(0,25) + '…' : t;
}
function rgbToHex(rgb) {
  if (!rgb) return '#000000';
  if (rgb.charAt(0) === '#') {
    var h = rgb.toUpperCase();
    if (h.length === 4) return '#' + h[1]+h[1]+h[2]+h[2]+h[3]+h[3];
    return h;
  }
  var m = rgb.match(/\d+/g);
  if (!m || m.length < 3) return '#000000';
  return '#' + ((1<<24)+(parseInt(m[0])<<16)+(parseInt(m[1])<<8)+parseInt(m[2])).toString(16).slice(1).toUpperCase();
}
function scanPageColors() {
  var freq = {};
  document.querySelectorAll('body *').forEach(function(el) {
    if (isLE(el)) return;
    var cs = window.getComputedStyle(el);
    var c = rgbToHex(cs.color);
    if (c !== '#000000' && c !== '#FFFFFF') freq[c] = (freq[c]||0) + 1;
    var bg = cs.backgroundColor;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
      var bh = rgbToHex(bg);
      if (bh !== '#FFFFFF' && bh !== '#000000') freq[bh] = (freq[bh]||0) + 1;
    }
  });
  var presetSet = {};
  TEXT_COLORS.forEach(function(tc) { presetSet[tc.c.toUpperCase()] = true; });
  var arr = Object.keys(freq).filter(function(c) { return !presetSet[c]; });
  arr.sort(function(a,b) { return freq[b] - freq[a]; });
  return arr.slice(0, 12);
}
function scanTextStyles() {
  var map = {};
  var SKIP = ['SCRIPT','STYLE','META','LINK','BR','HR','IMG','SVG','PATH','CIRCLE','RECT','LINE','INPUT','SELECT','TEXTAREA','BUTTON'];
  document.querySelectorAll('body *').forEach(function(el) {
    if (isLE(el)) return;
    if (SKIP.indexOf(el.tagName) !== -1) return;
    var hasTxt = false;
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3 && el.childNodes[i].textContent.trim()) { hasTxt = true; break; }
    }
    if (!hasTxt) return;
    var cs = window.getComputedStyle(el);
    var sz = Math.round(parseFloat(cs.fontSize));
    var wt = parseInt(cs.fontWeight);
    var cl = rgbToHex(cs.color);
    var key = sz + '-' + wt + '-' + cl;
    if (!map[key]) map[key] = { size:sz, weight:wt, color:cl, count:0, sample:el.textContent.trim().substring(0,6) };
    map[key].count++;
  });
  var arr = Object.values(map);
  arr.sort(function(a,b) { return b.size - a.size || b.weight - a.weight; });
  return arr.slice(0, 12);
}
function weightName(w) {
  if (w <= 300) return '细体';
  if (w <= 400) return '常规';
  if (w <= 500) return '中等';
  if (w <= 600) return '半粗';
  if (w <= 700) return '粗体';
  return '超粗';
}

/* ═══════════════════════ ICONS ═══════════════════════ */
const I = {
  hl: '<svg viewBox="0 0 16 16"><path d="M11 1.5l3.5 3.5L8 11.5H4.5V8L11 1.5z" fill="currentColor" opacity=".45"/><rect x=".5" y="13" width="15" height="2.5" rx="1" fill="#FFF176"/></svg>',
  ct: '<svg viewBox="0 0 16 16"><rect x="2" y="2.5" width="12" height="1.8" rx=".9" fill="currentColor"/><rect x="4" y="7.1" width="8" height="1.8" rx=".9" fill="currentColor"/><rect x="2" y="11.7" width="12" height="1.8" rx=".9" fill="currentColor"/></svg>',
  dv: '<svg viewBox="0 0 16 16"><line x1="1" y1="8" x2="15" y2="8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  dg: '<svg viewBox="0 0 16 16"><circle cx="5.5" cy="3" r="1.3" fill="currentColor"/><circle cx="10.5" cy="3" r="1.3" fill="currentColor"/><circle cx="5.5" cy="8" r="1.3" fill="currentColor"/><circle cx="10.5" cy="8" r="1.3" fill="currentColor"/><circle cx="5.5" cy="13" r="1.3" fill="currentColor"/><circle cx="10.5" cy="13" r="1.3" fill="currentColor"/></svg>',
  im: '<svg viewBox="0 0 16 16"><rect x="1" y="2.5" width="14" height="11" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="5.2" cy="6.2" r="1.4" fill="currentColor" opacity=".5"/><path d="M3 12l3.2-3.6 2.2 2.2 2.4-3 2.2 2.6" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  sp: '<svg viewBox="0 0 16 16"><path d="M8 1.5v13" stroke="currentColor" stroke-width="1.2" stroke-dasharray="2 1.6"/><path d="M4.5 4L2 6.5 4.5 9" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M11.5 4L14 6.5 11.5 9" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};
/* A-/A+ 直接用文字，在 btn() 中传入 */

/* ═══════════════════════ BUILD UI ═══════════════════════ */
const root = mk('div','le-root');
const box  = mk('div','le-box');

// 编辑图标
const iconW = mk('div','le-icon-w','<span>✏️</span>');
iconW.appendChild(mk('div','le-tip-main','实时编辑工具 · 可拖动'));
box.appendChild(iconW);

// 工具栏
const bar = mk('div','le-bar');

// 状态指示
const statusW = mk('div','le-status');
const dotEl   = mk('span','le-dot');
const cntEl   = mk('span','','0处');
const undoB   = mk('button','le-undo','↩ 撤回');
undoB.disabled = true;
undoB.title = '撤回上一步操作（删除/新增/换图/全局同步/文字）';
undoB.addEventListener('click', function(e) { e.stopPropagation(); doUndo(); });
statusW.append(dotEl, cntEl, undoB, mk('span','le-tt','已修改的元素数量'));

// 工具按钮
const bHL = btn('hl', I.hl+'高亮', '选中文字后点击高亮，再点取消', doHighlight);
const bFD = btn('fd', 'A-', '点击缩小当前文字', function() { doFontSize(-2); });
const bFU = btn('fu', 'A+', '点击放大当前文字', function() { doFontSize(2); });
const bCT = btn('ct', I.ct+'居中', '切换文字居中/左对齐', doCenter);
const bDV = btn('dv', I.dv+'分割线', '在当前元素下方插入分割线', doDivider);
const bDG = btn('dg', I.dg+'拖拽', '开启后可拖动模块换位置', doDragToggle);
const bIM = btn('im', I.im+'换图', '开启后点击图片即可替换', doImgToggle);
const bSP = btn('sp', I.sp+'间距', '调整选中元素的内边距/外边距', doSpcToggle);
const bDL = btn('dl', '删除', '开启：悬停显示红描边，双击模块即可删除；Esc 退出', doDelToggle);
const bAD = btn('ad', '新增', '开启：点击同类项，选 上/下/左/右 插入克隆副本；Esc 退出', doAddToggle);

// ── 换色按钮 + 多段式面板 ──
var TEXT_COLORS = [
  {c:'#333333',n:'默认黑'},
  {c:'#7C48DB',n:'国际紫'},
  {c:'#E53935',n:'红色'},
  {c:'#1976D2',n:'蓝色'},
  {c:'#2E7D32',n:'绿色'},
  {c:'#F57C00',n:'橙色'}
];
var bCC = btn('cc', '<span style="display:inline-flex;flex-direction:column;align-items:center;gap:1px;pointer-events:none"><span style="font-weight:700;font-size:12px;line-height:1">A</span><span class="le-cbar" style="display:block;width:10px;height:2px;border-radius:1px;background:#E53935"></span></span>', '颜色 · 配色板 · 吸色', function(e) {
  e.stopPropagation();
  if (!cpanel.classList.contains('le-show')) refreshPagePalette();
  cpanel.classList.toggle('le-show');
  spanel.classList.remove('le-show');
});
var colorBar = bCC.querySelector('.le-cbar');

// 面板容器
var cpanel = mk('div','le-cp');

// S1: 常用色
cpanel.appendChild(mk('div','le-cs-h','常用色'));
var presetRow = mk('div','le-cs-row');
TEXT_COLORS.forEach(function(tc) {
  var dot = mk('span','le-cd');
  dot.style.background = tc.c;
  dot.title = tc.n;
  dot.addEventListener('click', function(ev) {
    ev.stopPropagation();
    doColor(tc.c);
    colorBar.style.background = tc.c;
  });
  presetRow.appendChild(dot);
});
// 自定义颜色（+号按钮 → 系统拾色器）
var cpkWrap = mk('span','le-cpk-w');
cpkWrap.title = '自定义颜色';
cpkWrap.innerHTML = '<svg viewBox="0 0 16 16"><path d="M8 3v10M3 8h10" stroke="#AAA" stroke-width="2" stroke-linecap="round" fill="none"/></svg>';
var cpkInput = document.createElement('input');
cpkInput.type = 'color';
cpkInput.value = '#7C48DB';
cpkInput.className = 'le-cpk';
cpkInput.addEventListener('input', function(ev) {
  ev.stopPropagation();
  var c = ev.target.value;
  doColor(c);
  colorBar.style.background = c;
  hexInput.value = c.toUpperCase();
});
cpkInput.addEventListener('click', function(ev) { ev.stopPropagation(); });
cpkWrap.appendChild(cpkInput);
presetRow.appendChild(cpkWrap);
cpanel.appendChild(presetRow);

// S2: 色值输入 + 吸色器
cpanel.appendChild(mk('div','le-cs-sep'));
var hexRow = mk('div','le-hex-row');
var hexInput = mk('input','le-hex-in');
hexInput.type = 'text';
hexInput.placeholder = '#色值，回车应用';
hexInput.maxLength = 7;
hexInput.addEventListener('keydown', function(ev) {
  ev.stopPropagation();
  if (ev.key === 'Enter') {
    var val = hexInput.value.trim();
    if (!val.startsWith('#')) val = '#' + val;
    if (/^#[0-9A-Fa-f]{3,6}$/.test(val)) {
      doColor(val); colorBar.style.background = val; hexInput.value = val.toUpperCase();
    } else { toast('请输入正确色值，如 #FF5500'); }
  }
});
hexInput.addEventListener('click', function(ev) { ev.stopPropagation(); });
hexRow.appendChild(hexInput);
var eyeBtn = mk('button','le-eye-btn');
eyeBtn.innerHTML = '<svg viewBox="0 0 16 16"><path d="M13.4 2.6a2 2 0 00-2.8 0L8.7 4.5l-.7-.7L6.6 5.2l.7.7-4.6 4.6V13h2.5l4.6-4.6.7.7 1.4-1.4-.7-.7 1.9-1.9a2 2 0 000-2.8z" fill="currentColor"/></svg>吸色';
eyeBtn.addEventListener('click', function(ev) {
  ev.stopPropagation();
  if (window.EyeDropper) {
    new EyeDropper().open().then(function(r) {
      var c = r.sRGBHex.toUpperCase();
      doColor(c); colorBar.style.background = c; hexInput.value = c;
    }).catch(function(){});
  } else { toast('当前浏览器不支持吸色器，请用 Chrome'); }
});
hexRow.appendChild(eyeBtn);
cpanel.appendChild(hexRow);

// S3: 页面配色
cpanel.appendChild(mk('div','le-cs-sep'));
cpanel.appendChild(mk('div','le-cs-h','页面配色'));
var ppRow = mk('div','le-cs-row');
cpanel.appendChild(ppRow);
function refreshPagePalette() {
  var colors = scanPageColors();
  ppRow.innerHTML = '';
  if (colors.length === 0) { ppRow.innerHTML = '<span class="le-pp-empty">暂无额外配色</span>'; return; }
  colors.forEach(function(c) {
    var dot = mk('span','le-cd');
    dot.style.background = c; dot.title = c;
    dot.addEventListener('click', function(ev) {
      ev.stopPropagation();
      doColor(c); colorBar.style.background = c; hexInput.value = c;
    });
    ppRow.appendChild(dot);
  });
}
bCC.appendChild(cpanel);

// ── 文字样式按钮 + 面板 ──
var bST = btn('st', '<svg viewBox="0 0 16 16"><text x="2" y="13" font-size="13" font-weight="700" fill="currentColor" font-family="serif">T</text><rect x="10" y="2" width="4" height="2.5" rx=".5" fill="currentColor" opacity=".5"/><rect x="10" y="6.5" width="4" height="2.5" rx=".5" fill="currentColor" opacity=".35"/><rect x="10" y="11" width="4" height="2.5" rx=".5" fill="currentColor" opacity=".2"/></svg>样式', '页面文字样式，点击一键应用', function(e) {
  e.stopPropagation();
  if (!spanel.classList.contains('le-show')) refreshStylePanel();
  spanel.classList.toggle('le-show');
  cpanel.classList.remove('le-show');
});
var spanel = mk('div','le-sp');
var styleListEl = mk('div','');
spanel.appendChild(mk('div','le-cs-h','页面文字样式'));
spanel.appendChild(styleListEl);
bST.appendChild(spanel);
function refreshStylePanel() {
  var styles = scanTextStyles();
  styleListEl.innerHTML = '';
  if (styles.length === 0) { styleListEl.innerHTML = '<div style="padding:12px;text-align:center;color:#CCC;font-size:12px">未检测到文字样式</div>'; return; }
  styles.forEach(function(s) {
    var item = mk('div','le-si');
    var preview = mk('span','le-si-preview','Aa ' + s.sample);
    preview.style.cssText = 'font-size:' + Math.min(s.size, 20) + 'px;font-weight:' + s.weight + ';color:' + s.color;
    var meta = mk('span','le-si-meta', s.size + 'px · ' + weightName(s.weight));
    item.appendChild(preview); item.appendChild(meta);
    item.title = s.size + 'px / ' + weightName(s.weight) + ' / ' + s.color + ' — 点击应用';
    item.addEventListener('click', function(ev) {
      ev.stopPropagation();
      if (S.activeEl) {
        S.activeEl.style.fontSize = s.size + 'px';
        S.activeEl.style.fontWeight = s.weight;
        S.activeEl.style.color = s.color;
        S.changeLog.push('将「' + elLabel(S.activeEl) + '」应用样式：' + s.size + 'px/' + weightName(s.weight) + '/' + s.color);
        showBadge(S.activeEl); bumpEdit(); spanel.classList.remove('le-show');
      } else { toast('请先点击要修改的文字'); }
    });
    styleListEl.appendChild(item);
  });
}

const saveB = mk('button','le-save','保存');
saveB.addEventListener('click', function(e) { e.stopPropagation(); showSaveModal(); });
const closeB = mk('button','le-close','×');
closeB.addEventListener('click', function(e) { e.stopPropagation(); doClose(); });

// 组装
[statusW, mk('span','le-sep'), bHL, bCC, bST, bFD, bFU, bCT, mk('span','le-sep'), bDV, bDG, bIM, bSP, bDL, bAD, mk('span','le-sep'), saveB, closeB].forEach(function(c) { bar.appendChild(c); });
box.appendChild(bar);
root.appendChild(box);

// 字号浮标
const fbadge = mk('div','le-fbadge');
document.body.appendChild(fbadge);

// 打开（拖拽刚结束时抑制本次点击，避免误展开）
box.addEventListener('click', function() {
  if (S.justDragged) { S.justDragged = false; return; }
  if (!S.open) doOpen();
});
document.body.appendChild(root);

/* ═══════════════════════ FAB 拖拽换位 ═══════════════════════ */
// 收起态下按住铅笔按钮可拖动整个入口到视口任意位置；
// 移动距离 < 阈值视为点击（展开工具栏），否则视为拖拽（不展开）。
// 位置写入 localStorage 记忆，下次注入自动恢复；展开时做右溢出校正。
(function enableFabDrag() {
  var STORE = 'le-fab-pos-v1';
  var OPEN_W = 884;   // 展开后预估宽度（max-width 860 + 余量）
  var TH = 4;         // 点击 / 拖拽判定阈值（px）
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function rootSize() { return { w: root.offsetWidth || 44, h: root.offsetHeight || 44 }; }
  function applyPos(x, y) {
    root.style.right = 'auto';
    root.style.left = x + 'px';
    root.style.top = y + 'px';
  }
  function curLT() { var r = root.getBoundingClientRect(); return { x: r.left, y: r.top }; }
  function loadPos() {
    try {
      var p = JSON.parse(localStorage.getItem(STORE) || 'null');
      if (p && typeof p.x === 'number' && typeof p.y === 'number') return p;
    } catch (e) {}
    return null;
  }
  function savePos(x, y) {
    try { localStorage.setItem(STORE, JSON.stringify({ x: Math.round(x), y: Math.round(y) })); } catch (e) {}
  }
  // 初始恢复记忆位置
  var saved = loadPos();
  if (saved) {
    var sz0 = rootSize();
    applyPos(clamp(saved.x, 0, window.innerWidth - sz0.w), clamp(saved.y, 0, window.innerHeight - sz0.h));
  }
  var dragging = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0, pid = null;
  box.addEventListener('pointerdown', function (e) {
    if (S.open || e.button !== 0) return;   // 展开态交给工具栏交互；仅响应主键
    dragging = true; moved = false;
    sx = e.clientX; sy = e.clientY;
    var lt = curLT(); ox = lt.x; oy = lt.y; pid = e.pointerId;
    try { box.setPointerCapture(pid); } catch (err) {}
    root.style.transition = 'none';
    box.style.cursor = 'grabbing';
  });
  box.addEventListener('pointermove', function (e) {
    if (!dragging) return;
    var dx = e.clientX - sx, dy = e.clientY - sy;
    if (!moved && Math.abs(dx) < TH && Math.abs(dy) < TH) return;
    moved = true;
    var sz = rootSize();
    applyPos(clamp(ox + dx, 0, window.innerWidth - sz.w), clamp(oy + dy, 0, window.innerHeight - sz.h));
  });
  function endDrag() {
    if (!dragging) return;
    dragging = false;
    try { if (pid != null) box.releasePointerCapture(pid); } catch (err) {}
    pid = null;
    root.style.transition = '';
    box.style.cursor = '';
    if (moved) {
      var lt = curLT();
      savePos(lt.x, lt.y);
      S.justDragged = true;   // 抑制紧随的 click，避免拖完误展开
      if (root.animate) root.animate(
        [{ transform: 'scale(1.08)' }, { transform: 'scale(1)' }],
        { duration: 200, easing: 'cubic-bezier(.34,1.56,.64,1)' }
      );
    }
  }
  box.addEventListener('pointerup', endDrag);
  box.addEventListener('pointercancel', endDrag);
  // 视口缩放时把按钮收回可见区域
  window.addEventListener('resize', function () {
    if (S.open) return;
    var lt = curLT(), sz = rootSize();
    applyPos(clamp(lt.x, 0, window.innerWidth - sz.w), clamp(lt.y, 0, window.innerHeight - sz.h));
  });
  // 展开时若工具栏会溢出右边界，则把入口左移到能容纳的位置
  S._fabClampForOpen = function () {
    var lt = curLT();
    if (lt.x + OPEN_W > window.innerWidth - 8) {
      applyPos(clamp(window.innerWidth - OPEN_W - 8, 0, lt.x), lt.y);
    }
  };
})();

// 标记脚本
document.currentScript && document.currentScript.setAttribute(LE_TAG, '1');

/* ═══════════════════════ OPEN / CLOSE ═══════════════════════ */
function doOpen() {
  S.open = true;
  box.classList.add('le-open');
  if (S._fabClampForOpen) S._fabClampForOpen();
  startEditing(true);
}
// Esc 退出当前结构模式
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    if (S.delMode) doDelToggle();
    else if (S.addMode) doAddToggle();
    else if (S.imgMode) doImgToggle();
    else if (S.dragMode) doDragToggle();
    closeAddPop();
  }
});
function doClose() {
  if (S.dragMode) stopDrag();
  if (S.imgMode) { S.imgMode = false; bIM.classList.remove('le-on'); closeImgPanel(); }
  if (S.delMode) doDelToggle();
  if (S.addMode) doAddToggle();
  if (spcPanel) closeSpcPanel();
  stopEditing();
  S.open = false;
  box.classList.remove('le-open');
  hideBadge();
  if (typeof hideHoverBar === 'function') hideHoverBar();  // v4.0：关闭编辑器时收起悬停操作条
}

/* ═══════════════════════ TEXT EDITING ═══════════════════════ */
function startEditing(fresh) {
  S.editing = true;
  var all = document.querySelectorAll('body *');
  // v2.1.4：从 skip 移除 BUTTON —— 让按钮文案可编辑（LE 自身按钮由 isLE() 在上方拦截，不受影响）
  var skip = ['SCRIPT','STYLE','META','LINK','BR','HR','IMG','SVG','PATH','CIRCLE','RECT','LINE',
              'VIDEO','AUDIO','CANVAS','IFRAME','INPUT','SELECT','TEXTAREA'];
  all.forEach(function(nd) {
    if (isLE(nd)) return;
    if (skip.indexOf(nd.tagName) !== -1) return;
    if (nd.classList.contains('le-ph') || nd.classList.contains('le-ghost')) return;
    // 检测是否含有直接文本
    var hasTxt = false;
    for (var i = 0; i < nd.childNodes.length; i++) {
      var c = nd.childNodes[i];
      if (c.nodeType === 3 && c.textContent.trim().length > 0) { hasTxt = true; break; }
    }
    if (hasTxt) {
      nd.setAttribute('contenteditable','true');
      nd.classList.add('le-editable');
    }
  });
  document.addEventListener('input', onInput, true);
  document.addEventListener('click', onDocClick, true);
  document.addEventListener('focusin', onFocusIn, true);
  // 快照：记录编辑前的文字和样式（fresh=false 表示从结构模式恢复，保留已有记录）
  if (fresh !== false) {
    S.textSnaps.clear();
    S.changeLog = [];
  }
  document.querySelectorAll('.le-editable').forEach(function(nd) {
    if (!S.textSnaps.has(nd)) S.textSnaps.set(nd, { text: nd.textContent.trim().replace(/\s+/g,' ') });
  });
}

function stopEditing(silent) {
  S.editing = false;
  // 关闭工具栏时做全局文案校准检查；结构模式暂停时静默跳过
  if (!silent) offerGlobalSync();
  document.querySelectorAll('.le-editable').forEach(function(nd) {
    nd.removeAttribute('contenteditable');
    nd.classList.remove('le-editable');
  });
  document.removeEventListener('input', onInput, true);
  document.removeEventListener('click', onDocClick, true);
  document.removeEventListener('focusin', onFocusIn, true);
  S.activeEl = null;
}

function onInput(e) {
  var t = e.target.closest && e.target.closest('.le-editable');
  if (t && !S.editedEls.has(t)) {
    S.editedEls.add(t);
    var snap = S.textSnaps.get(t);
    if (snap) pushUndo({ type: 'text', nd: t, old: snap.text }); // v3.3 文字可撤回
    refreshCount();
  }
}
function onFocusIn(e) {
  var t = e.target.closest && e.target.closest('.le-editable');
  if (t) { S.activeEl = t; syncBtnStates(); }
}
function onDocClick(e) {
  // 点击面板外部时收起
  if (!e.target.closest('.le-cp') && !e.target.closest('[data-tool="cc"]')) {
    cpanel.classList.remove('le-show');
  }
  if (!e.target.closest('.le-sp') && !e.target.closest('[data-tool="st"]')) {
    spanel.classList.remove('le-show');
  }
  if (isLE(e.target)) return;
  // v3.3：删除/新增/换图的点击由常驻监听 onStructClick 处理（与文本编辑解耦）
  var t = e.target.closest && e.target.closest('.le-editable');
  if (t) {
    S.activeEl = t;
    showBadge(t);
    syncBtnStates();
  } else {
    S.activeEl = null;
    hideBadge();
    syncBtnStates();
  }
}

/* ── v3.4 常驻结构点击监听：删除/新增/换图模式与文本编辑完全解耦 ── */
// 页面级容器护栏：宽 > 600px 或超过视口 50% 或 body 直接子级 → 不可作为换图目标
function isPageLevel(el) {
  if (!el || el === document.body || el.parentElement === document.body) return true;
  var r = el.getBoundingClientRect();
  return r.width > 600 || r.width > window.innerWidth * 0.5;
}
function isPlaceholderSlot(el) {
  if (!el || el.tagName === 'IMG') return false;
  if (isPageLevel(el)) return false; // 拒绝页面级容器
  var r = el.getBoundingClientRect();
  if (r.width < 40 || r.height < 40) return false;
  if (r.width > 600) return false; // 超大元素不是图槽
  var cs = window.getComputedStyle(el);
  if (cs.backgroundImage && cs.backgroundImage !== 'none') return true;
  if (el.querySelector && el.querySelector('svg') && !el.querySelector('img')) return true;
  // v3.4 新增：识别纯灰色占位块（浅灰背景 + 无实际文字）
  var bg = cs.backgroundColor;
  if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
    var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (m) {
      var rr = +m[1], gg = +m[2], bb = +m[3];
      var isGrayish = Math.abs(rr - gg) < 30 && Math.abs(gg - bb) < 30 && rr > 180 && rr < 250;
      var hasMeaningfulText = (el.textContent || '').trim().length > 6;
      if (isGrayish && !hasMeaningfulText) return true;
    }
  }
  return false;
}
function findSlot(el) {
  var cur = el, hops = 0;
  while (cur && cur !== document.body && hops < 3) { // v3.4: 上溯收紧到 3 层
    if (cur.tagName === 'IMG') return cur; // IMG 优先
    if (isPlaceholderSlot(cur)) return cur;
    cur = cur.parentElement; hops++;
  }
  return null;
}
// v3.4 换图模式 hover 高亮
var imgHoverUnit = null;
function onImgHover(e) {
  if (!S.imgMode) return;
  if (isLE(e.target)) { clearImgHover(); return; }
  var target = null;
  if (e.target.tagName === 'IMG') target = e.target;
  else target = findSlot(e.target);
  if (target && !isPageLevel(target)) {
    if (imgHoverUnit && imgHoverUnit !== target) imgHoverUnit.classList.remove('le-img-unit');
    imgHoverUnit = target;
    target.classList.add('le-img-unit');
  } else {
    clearImgHover();
  }
}
function clearImgHover() {
  if (imgHoverUnit) { imgHoverUnit.classList.remove('le-img-unit'); imgHoverUnit = null; }
}
function onStructClick(e) {
  if (isLE(e.target)) return;
  if (S.delMode) {
    e.preventDefault(); e.stopImmediatePropagation();
    doDelAt(e.target);
    return;
  }
  if (S.addMode) {
    e.preventDefault(); e.stopImmediatePropagation();
    doAddAt(e.target);
    return;
  }
  if (S.imgMode) {
    if (imgPanel && imgPanel.contains(e.target)) return;
    if (e.target.tagName === 'IMG') {
      e.preventDefault(); e.stopImmediatePropagation();
      openImgPanel(e.target);
      return;
    }
    var slot = findSlot(e.target);
    if (slot) {
      e.preventDefault(); e.stopImmediatePropagation();
      openImgPanel(slot);
      return;
    }
    toast('请点击要替换的图片或占位图块');
    e.stopImmediatePropagation();
    return;
  }
}
document.addEventListener('click', onStructClick, true);

function refreshCount() {
  var n = S.editedEls.size + S.structEdits;
  cntEl.textContent = n + '处';
  dotEl.classList.toggle('le-has', n > 0);
}
function syncBtnStates() {
  if (S.activeEl) {
    var cs = window.getComputedStyle(S.activeEl);
    bCT.classList.toggle('le-on', cs.textAlign === 'center');
    bHL.classList.toggle('le-on', S.activeEl.classList.contains('le-hl'));
  } else {
    bCT.classList.remove('le-on');
    bHL.classList.remove('le-on');
  }
}

/* ═══════════════════════ 换色 ═══════════════════════ */
function doColor(color) {
  if (!S.editing) return;
  var sel = window.getSelection();
  // 有选区 → 仅选中文字换色
  if (sel && sel.rangeCount > 0 && !sel.isCollapsed) {
    var selText = sel.toString().trim();
    try {
      var range = sel.getRangeAt(0);
      var span = document.createElement('span');
      span.style.color = color;
      range.surroundContents(span);
    } catch(err) {
      document.execCommand('foreColor', false, color);
    }
    S.changeLog.push('将选中文字「' + (selText.length>20?selText.substring(0,20)+'…':selText) + '」颜色改为 ' + color);
    bumpEdit();
    return;
  }
  // 无选区 → 整个元素换色
  if (S.activeEl) {
    S.activeEl.style.color = color;
    S.changeLog.push('将「' + elLabel(S.activeEl) + '」文字颜色改为 ' + color);
    bumpEdit();
  } else {
    toast('请先选中文字或点击元素');
  }
}

/* ═══════════════════════ 高亮 ═══════════════════════ */
function doHighlight() {
  if (!S.editing) return;
  var sel = window.getSelection();
  // 有选区 → 高亮选中文字
  if (sel && sel.rangeCount > 0 && !sel.isCollapsed) {
    var hlSelText = sel.toString().trim();
    var anc = sel.anchorNode;
    var parent = anc && anc.nodeType === 3 ? anc.parentElement : anc;
    if (parent && parent.classList.contains('le-hl')) {
      var pp = parent.parentNode;
      while (parent.firstChild) pp.insertBefore(parent.firstChild, parent);
      pp.removeChild(parent);
      pp.normalize();
      S.changeLog.push('取消高亮「' + (hlSelText.length>20?hlSelText.substring(0,20)+'…':hlSelText) + '」');
    } else {
      try {
        var range = sel.getRangeAt(0);
        var span = document.createElement('span');
        span.className = 'le-hl';
        range.surroundContents(span);
      } catch(err) {
        document.execCommand('backColor', false, HL_COLOR);
      }
      S.changeLog.push('高亮标记「' + (hlSelText.length>20?hlSelText.substring(0,20)+'…':hlSelText) + '」');
    }
    bumpEdit(); syncBtnStates();
    return;
  }
  // 无选区 → 整元素高亮切换
  if (S.activeEl) {
    var wasHL = S.activeEl.classList.contains('le-hl');
    S.activeEl.classList.toggle('le-hl');
    S.changeLog.push((wasHL?'取消':'添加') + '高亮「' + elLabel(S.activeEl) + '」');
    bumpEdit(); syncBtnStates();
  } else {
    toast('请先选中文字或点击元素');
  }
}

/* ═══════════════════════ 字号调整 ═══════════════════════ */
function doFontSize(delta) {
  if (!S.activeEl) { toast('请先点击要调整的文字'); return; }
  var cur = parseFloat(window.getComputedStyle(S.activeEl).fontSize);
  var nxt = Math.max(10, Math.min(72, cur + delta));
  S.activeEl.style.fontSize = nxt + 'px';
  S.changeLog.push('将「' + elLabel(S.activeEl) + '」字号从 ' + cur + 'px 调为 ' + nxt + 'px');
  showBadge(S.activeEl);
  bumpEdit();
}

/* ═══════════════════════ 居中 ═══════════════════════ */
function doCenter() {
  if (!S.activeEl) { toast('请先点击要对齐的文字'); return; }
  var cs = window.getComputedStyle(S.activeEl);
  if (cs.textAlign === 'center') {
    S.activeEl.style.textAlign = '';
    bCT.classList.remove('le-on');
    S.changeLog.push('将「' + elLabel(S.activeEl) + '」改为左对齐');
  } else {
    S.activeEl.style.textAlign = 'center';
    bCT.classList.add('le-on');
    S.changeLog.push('将「' + elLabel(S.activeEl) + '」改为居中');
  }
  bumpEdit();
}

/* ═══════════════════════ 分割线 ═══════════════════════ */
function doDivider() {
  var target = S.activeEl;
  if (!target) {
    var wrap = document.querySelector('.page-wrap') || document.body;
    var kids = wrap.children;
    target = kids[kids.length - 1];
  }
  if (!target || isLE(target)) return;
  var hr = mk('div','le-hr');
  hr.appendChild(mk('span','le-tt','点击删除此分割线'));
  target.parentNode.insertBefore(hr, target.nextSibling);
  requestAnimationFrame(function() {
    requestAnimationFrame(function() { hr.classList.add('le-vis'); });
  });
  hr.addEventListener('click', function() {
    hr.classList.remove('le-vis');
    setTimeout(function() { hr.remove(); }, 350);
  });
  S.changeLog.push('在「' + elLabel(target) + '」下方插入分割线');
  S.structEdits++;
  refreshCount();
}

/* ═══════════════════════ v3.1 图片替换 ═══════════════════════ */
var imgPanel = null;
var imgTarget = null;

function doImgToggle() {
  S.imgMode = !S.imgMode;
  bIM.classList.toggle('le-on', S.imgMode);
  document.body.classList.toggle('le-imgmode', S.imgMode);
  if (S.imgMode) {
    exitOtherModes('img');
    document.addEventListener('mouseover', onImgHover, true);
    toast('换图模式已开启：悬停显示紫色描边，点击图片或占位图块即可替换；Esc 退出');
  } else {
    document.removeEventListener('mouseover', onImgHover, true);
    clearImgHover();
    closeImgPanel();
    toast('换图模式已关闭');
  }
  syncTextEditing();
}

function openImgPanel(img) {
  closeImgPanel();
  imgTarget = img;
  imgPanel = mk('div','le-img-panel');
  imgPanel.innerHTML =
    '<div class="le-ip-hd"><span>替换图片</span><button class="le-ip-x" title="关闭">×</button></div>' +
    '<button class="le-ip-btn le-ip-upload">📁 上传本地图片</button>' +
    '<button class="le-ip-btn le-ip-url-btn">🔗 粘贴图片链接</button>' +
    '<input class="le-ip-url" placeholder="https://…" style="display:none" />' +
    '<div class="le-ip-tip">本地图片将转为 base64 内联，离线可用</div>';
  document.body.appendChild(imgPanel);

  // 定位：图片右下方，超出视口则翻转
  var r = img.getBoundingClientRect();
  var px = r.right + 8;
  var py = r.top;
  if (px + 204 > window.innerWidth) px = Math.max(8, r.left - 204);
  if (py + 170 > window.innerHeight) py = Math.max(8, window.innerHeight - 170);
  imgPanel.style.left = px + 'px';
  imgPanel.style.top = py + 'px';
  requestAnimationFrame(function() { imgPanel && imgPanel.classList.add('le-show'); });

  var fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  fileInput.style.display = 'none';
  imgPanel.appendChild(fileInput);

  imgPanel.querySelector('.le-ip-x').addEventListener('click', function(ev) {
    ev.stopPropagation(); closeImgPanel();
  });
  imgPanel.querySelector('.le-ip-upload').addEventListener('click', function(ev) {
    ev.stopPropagation(); fileInput.click();
  });
  fileInput.addEventListener('change', function() {
    var f = fileInput.files && fileInput.files[0];
    if (!f) return;
    var reader = new FileReader();
    reader.onload = function(e) { applyImgReplace(imgTarget, e.target.result, f.name); };
    reader.readAsDataURL(f);
  });
  var urlInput = imgPanel.querySelector('.le-ip-url');
  imgPanel.querySelector('.le-ip-url-btn').addEventListener('click', function(ev) {
    ev.stopPropagation();
    urlInput.style.display = urlInput.style.display === 'none' ? 'block' : 'none';
    if (urlInput.style.display === 'block') urlInput.focus();
  });
  urlInput.addEventListener('keydown', function(ev) {
    ev.stopPropagation();
    if (ev.key === 'Enter' && urlInput.value.trim()) {
      applyImgReplace(imgTarget, urlInput.value.trim(), urlInput.value.trim());
    }
  });
  urlInput.addEventListener('click', function(ev) { ev.stopPropagation(); });
}

function applyImgReplace(img, newSrc, label) {
  if (!img) return;
  var isBg = img.tagName !== 'IMG'; // v3.3：占位槽（div 背景图）
  // v3.4 护栏：背景替换目标若是页面级容器，直接拒绝（防止把图贴到整页背景）
  if (isBg && isPageLevel(img)) {
    toast('目标区域过大（页面容器），已拒绝替换；请点击具体的图片/占位图块');
    closeImgPanel();
    return;
  }
  var oldSrc = isBg ? (img.style.backgroundImage || '') : (img.getAttribute('src') || '');
  var oldLabel = oldSrc.length > 40 ? oldSrc.substring(0, 40) + '…' : oldSrc;
  if (isBg) {
    img.style.backgroundImage = 'url("' + newSrc + '")';
    img.style.backgroundSize = 'cover';
    img.style.backgroundPosition = 'center';
    img.style.backgroundColor = 'transparent';
  } else {
    img.setAttribute('src', newSrc);
  }
  var newLabel = label.length > 40 ? label.substring(0, 40) + '…' : label;
  pushUndo({ type: 'img', node: img, isBg: isBg, old: oldSrc });
  S.changeLog.push('将「' + (img.alt || img.className || (isBg ? '占位图块' : '图片')) + '」的图片从「' + oldLabel + '」替换为「' + newLabel + '」');
  S.structEdits++;
  refreshCount();
  toast('图片已替换，可点「撤回」恢复');
  closeImgPanel();
}

function closeImgPanel() {
  if (imgPanel) { imgPanel.remove(); imgPanel = null; }
  imgTarget = null;
}

/* ═══════════════════════ v3.1 间距调整 ═══════════════════════ */
var spcPanel = null;
var spcTarget = null;
var spcBase = {};  // 记录调整前的原始值，用于变更记录

function doSpcToggle() {
  if (spcPanel) { closeSpcPanel(); return; }
  var target = S.activeEl;
  if (!target) { toast('请先点击选中一个元素，再调整间距'); return; }
  spcTarget = target;
  target.classList.add('le-spc-hint');

  var cs = window.getComputedStyle(target);
  spcBase = {
    pt: parseFloat(cs.paddingTop) || 0,
    pb: parseFloat(cs.paddingBottom) || 0,
    pl: parseFloat(cs.paddingLeft) || 0,
    pr: parseFloat(cs.paddingRight) || 0,
    mt: parseFloat(cs.marginTop) || 0,
    mb: parseFloat(cs.marginBottom) || 0
  };

  spcPanel = mk('div','le-spc');
  spcPanel.innerHTML =
    '<div class="le-spc-hd">间距调整 · ' + elLabel(target) + '</div>' +
    spcRowHTML('上下内边距', 'py') +
    spcRowHTML('左右内边距', 'px') +
    '<div class="le-spc-sep"></div>' +
    spcRowHTML('上方外边距', 'mt') +
    spcRowHTML('下方外边距', 'mb') +
    '<div class="le-spc-ft">每次 ±4px · 实时生效 · 保存后可导出修改记录</div>';
  box.appendChild(spcPanel);
  requestAnimationFrame(function() { spcPanel && spcPanel.classList.add('le-show'); });
  bSP.classList.add('le-on');

  spcPanel.querySelectorAll('.le-spc-btn').forEach(function(b) {
    b.addEventListener('click', function(ev) {
      ev.stopPropagation();
      var kind = b.dataset.kind;
      var delta = parseInt(b.dataset.delta, 10);
      adjustSpacing(kind, delta);
    });
  });
  refreshSpcVals();
}

function spcRowHTML(label, kind) {
  return '<div class="le-spc-row">' +
    '<span class="le-spc-lb">' + label + '</span>' +
    '<button class="le-spc-btn" data-kind="' + kind + '" data-delta="-4">−</button>' +
    '<span class="le-spc-val" data-val="' + kind + '">--</span>' +
    '<button class="le-spc-btn" data-kind="' + kind + '" data-delta="4">＋</button>' +
    '</div>';
}

function adjustSpacing(kind, delta) {
  if (!spcTarget) return;
  var st = spcTarget.style;
  var cs = window.getComputedStyle(spcTarget);
  function cur(prop) { return parseFloat(cs[prop]) || 0; }
  function set(prop, val) { st[prop] = Math.max(0, val) + 'px'; }
  if (kind === 'py') {
    set('paddingTop', cur('paddingTop') + delta);
    set('paddingBottom', cur('paddingBottom') + delta);
  } else if (kind === 'px') {
    set('paddingLeft', cur('paddingLeft') + delta);
    set('paddingRight', cur('paddingRight') + delta);
  } else if (kind === 'mt') {
    set('marginTop', cur('marginTop') + delta);
  } else if (kind === 'mb') {
    set('marginBottom', cur('marginBottom') + delta);
  }
  refreshSpcVals();
}

function refreshSpcVals() {
  if (!spcPanel || !spcTarget) return;
  var cs = window.getComputedStyle(spcTarget);
  function px(v) { return Math.round(parseFloat(cs[v]) || 0) + 'px'; }
  function setVal(kind, text) {
    var el = spcPanel.querySelector('[data-val="' + kind + '"]');
    if (el) el.textContent = text;
  }
  setVal('py', px('paddingTop'));
  setVal('px', px('paddingLeft'));
  setVal('mt', px('marginTop'));
  setVal('mb', px('marginBottom'));
}

function closeSpcPanel() {
  if (spcPanel && spcTarget) {
    // 记录变更（与调整前对比）
    var cs = window.getComputedStyle(spcTarget);
    function now(prop) { return Math.round(parseFloat(cs[prop]) || 0); }
    var diffs = [];
    if (now('paddingTop') !== Math.round(spcBase.pt) || now('paddingBottom') !== Math.round(spcBase.pb))
      diffs.push('内边距(上下) ' + Math.round(spcBase.pt) + 'px → ' + now('paddingTop') + 'px');
    if (now('paddingLeft') !== Math.round(spcBase.pl) || now('paddingRight') !== Math.round(spcBase.pr))
      diffs.push('内边距(左右) ' + Math.round(spcBase.pl) + 'px → ' + now('paddingLeft') + 'px');
    if (now('marginTop') !== Math.round(spcBase.mt))
      diffs.push('上外边距 ' + Math.round(spcBase.mt) + 'px → ' + now('marginTop') + 'px');
    if (now('marginBottom') !== Math.round(spcBase.mb))
      diffs.push('下外边距 ' + Math.round(spcBase.mb) + 'px → ' + now('marginBottom') + 'px');
    if (diffs.length > 0) {
      S.changeLog.push('调整「' + elLabel(spcTarget) + '」的间距：' + diffs.join('；'));
      S.structEdits++;
      refreshCount();
    }
    spcTarget.classList.remove('le-spc-hint');
  }
  if (spcPanel) { spcPanel.remove(); spcPanel = null; }
  spcTarget = null;
  bSP.classList.remove('le-on');
}

/* ═══════════════════════ v3.3 模式互斥与文本编辑暂停 ═══════════════════════ */
// 拖拽/换图/新增/删除 四模式互斥：开启任一模式时暂停文本可编辑，避免与描边/点击冲突
function anyStructMode() { return S.dragMode || S.imgMode || S.addMode || S.delMode; }
function exitOtherModes(keep) {
  if (keep !== 'drag' && S.dragMode) doDragToggle();
  if (keep !== 'img'  && S.imgMode)  doImgToggle();
  if (keep !== 'add'  && S.addMode)  doAddToggle();
  if (keep !== 'del'  && S.delMode)  doDelToggle();
}
function syncTextEditing() {
  // 结构模式开启时静默暂停文本编辑；全部退出后恢复（保留已有记录）
  if (anyStructMode()) { if (S.editing) stopEditing(true); }
  else { if (!S.editing && S.open) startEditing(false); }
  // v4.0：任一 legacy 结构模式激活时隐藏悬停操作条（二者共存，避免双套手柄）
  if (anyStructMode() && typeof hideHoverBar === 'function') hideHoverBar();
}

/* ═══════════════════════ v3.3 撤回栈 ═══════════════════════ */
function pushUndo(entry) {
  S.undoStack.push(entry);
  if (undoB) undoB.disabled = false;
}
function doUndo() {
  var e = S.undoStack.pop();
  if (!e) { toast('没有可撤回的操作'); return; }
  try {
    if (e.type === 'del') {
      if (e.parent && e.parent.isConnected) {
        if (e.next && e.next.isConnected) e.parent.insertBefore(e.node, e.next);
        else e.parent.appendChild(e.node);
      }
      toast('已撤回删除');
    } else if (e.type === 'add') {
      // v3.5 兼容整组克隆（nodes 数组）与旧单节点（node）
      if (e.nodes && e.nodes.length) { e.nodes.forEach(function(n) { if (n.isConnected) n.remove(); }); }
      else if (e.node && e.node.isConnected) e.node.remove();
      toast('已撤回新增');
    } else if (e.type === 'move') {
      // v2.1.2：撤回悬停操作条的直接拖拽移动
      if (e.node && e.node.isConnected && e.origParent && e.origParent.isConnected) {
        if (e.origNext && e.origNext.isConnected) e.origParent.insertBefore(e.node, e.origNext);
        else e.origParent.appendChild(e.node);
      }
      toast('已撤回移动');
    } else if (e.type === 'img') {
      if (e.node.isConnected) {
        if (e.isBg) { e.node.style.backgroundImage = e.old; }
        else { e.node.setAttribute('src', e.old); }
      }
      toast('已撤回换图');
    } else if (e.type === 'text') {
      if (e.nd.isConnected) e.nd.textContent = e.old;
      toast('已撤回文字修改');
    } else if (e.type === 'sync') {
      e.items.forEach(function(it) { if (it.nd.isConnected) it.nd.textContent = it.old; });
      toast('已撤回全局同步');
    }
  } catch (err) { /* 节点已不存在等情况，静默跳过 */ }
  S.changeLog.push('撤回了上一步操作（' + e.type + '）');
  if (S.structEdits > 0) S.structEdits--;
  refreshCount();
  if (undoB) undoB.disabled = S.undoStack.length === 0;
}

/* ═══════════════════════ v3.3 同类单元上溯 ═══════════════════════ */
// 从点击元素上溯到"布局容器的直接子级"，保证删除/克隆的是完整同类项
function findUnit(el) {
  var cur = el, hops = 0;
  while (cur && cur.parentElement && cur.parentElement !== document.body && hops < 6) {
    var p = cur.parentElement;
    var d = window.getComputedStyle(p).display;
    if ((d === 'flex' || d === 'grid' || d === 'inline-flex' || d === 'inline-grid')) {
      return cur; // cur 是布局容器的直接子级 = 一个完整同类单元
    }
    cur = p; hops++;
  }
  return cur || el;
}
/* ── v3.6 页面级容器保护：整页/核心工作区不可删除、不可复制 ── */
function isProtectedUnit(el) {
  if (!el || el === document.body) return true;
  if (el.parentElement === document.body) return true; // body 直接子级 = 页面级骨架
  var r = el.getBoundingClientRect();
  if (r.width > window.innerWidth * 0.9) return true;  // 宽度接近整页
  if (r.height > window.innerHeight * 0.8) return true; // 高度接近整屏
  var cs = window.getComputedStyle(el);
  var ov = cs.overflowY;
  if ((ov === 'auto' || ov === 'scroll') && el.scrollHeight > el.clientHeight + 40 &&
      el.clientHeight > window.innerHeight * 0.5) return true; // 主滚动容器
  return false;
}

/* ═══════════════════════ v3.5 模块删除（悬停红描边 + 双击删除，无浮动图标） ═══════════════════════ */
function onDelHover(e) {
  if (!S.delMode) return;
  if (isLE(e.target)) { onDelLeave(); return; }
  var unit = promoteUnit(findUnit(e.target)); // v3.7：红描边框住整组（wrapper）
  // v3.6：页面级容器（整页/核心工作区）不显示红描边、不可选中
  if (isProtectedUnit(unit)) { onDelLeave(); return; }
  if (S.delUnit && S.delUnit !== unit) { S.delUnit.classList.remove('le-del-unit'); }
  S.delUnit = unit;
  unit.classList.add('le-del-unit');
}
function onDelLeave() {
  if (S.delUnit) { S.delUnit.classList.remove('le-del-unit'); }
  S.delUnit = null;
}
function doDelToggle() {
  S.delMode = !S.delMode;
  bDL.classList.toggle('le-on', S.delMode);
  document.body.classList.toggle('le-delmode', S.delMode);
  if (S.delMode) {
    exitOtherModes('del');
    document.addEventListener('mouseover', onDelHover, true);
    document.addEventListener('mouseleave', onDelLeave, true);
    toast('删除模式：悬停显示红描边，双击模块即可删除；Esc 或再点按钮退出');
  } else {
    document.removeEventListener('mouseover', onDelHover, true);
    document.removeEventListener('mouseleave', onDelLeave, true);
    onDelLeave();
    toast('删除模式已关闭');
  }
  syncTextEditing();
}

function doDelAt(el) {
  if (!el || isLE(el)) return;
  var unit = promoteUnit(findUnit(el)); // v3.7：筛选组按整组（wrapper）删除
  // v3.5：第一次点击 = 选中提示；第二次点击（双击）= 直接删除
  if (S.delArmed && S.delUnit === unit) {
    var label = elLabel(unit);
    var parent = unit.parentElement, next = unit.nextElementSibling;
    unit.remove();
    pushUndo({ type: 'del', node: unit, parent: parent, next: next });
    S.changeLog.push('删除了组件/模块「' + label + '」');
    S.structEdits++;
    refreshCount();
    S.delArmed = false; S.delUnit = null;
    toast('已删除「' + label + '」，可点「撤回」恢复');
  } else {
    if (S.delUnit) { S.delUnit.classList.remove('le-del-unit'); }
    S.delUnit = unit; S.delArmed = true;
    unit.classList.add('le-del-unit');
    toast('再点一次该模块即可删除「' + elLabel(unit) + '」（双击删除）；点别处取消');
  }
}

/* ═══════════════════════ v3.3 同类项新增（方向选择） ═══════════════════════ */
var addPop = null;
function closeAddPop() { if (addPop) { addPop.remove(); addPop = null; } }
function doAddToggle() {
  S.addMode = !S.addMode;
  bAD.classList.toggle('le-on', S.addMode);
  document.body.classList.toggle('le-addmode', S.addMode);
  if (S.addMode) {
    exitOtherModes('add');
    toast('新增模式：点击一个筛选项/选项卡/卡片，选择上/下/左/右插入克隆副本；Esc 退出');
  } else {
    closeAddPop();
    toast('新增模式已关闭');
  }
  syncTextEditing();
}
/* ── v3.5 容器轴向 / 筛选组合并 / 轴向插入 ── */
function containerAxis(c) {
  var d = window.getComputedStyle(c).display;
  if (d.indexOf('flex') !== -1) {
    var fd = window.getComputedStyle(c).flexDirection;
    return (fd === 'row' || fd === 'row-reverse') ? 'h' : 'v';
  }
  if (d.indexOf('grid') !== -1) {
    var ch = c.children;
    if (ch.length >= 2) {
      var r1 = ch[0].getBoundingClientRect(), r2 = ch[1].getBoundingClientRect();
      return Math.abs(r2.left - r1.left) > Math.abs(r2.top - r1.top) ? 'h' : 'v';
    }
    return 'h';
  }
  return 'v'; // block 默认纵向堆叠
}
function hasFormControl(el) {
  if (!el) return false;
  if (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') return true;
  return !!(el.querySelector && el.querySelector('input,select,textarea'));
}
// 筛选组识别：点击的是控件且其前一个兄弟是纯文字标题（如「商品名称/商品ID」）→ 合并为一组复制对象
// v3.7：若点击的控件/标题同处一个「纵向小 wrapper」（筛选项 = 上标题+下控件，wrapper 常为 flex column），
// 上溯为该 wrapper 整体作为复制/删除单元，保持上下结构；否则 findUnit 会在 wrapper 处停下返回控件，
// 拆成 [标题, 控件] 两个节点插入横向行容器后变成横向排布（v3.6 缺陷）
function promoteUnit(unit) {
  var p = unit.parentElement;
  if (p && !isProtectedUnit(p) && p.children.length <= 4 && containerAxis(p) === 'v') {
    var hasLabel = false, hasCtl = false;
    for (var i = 0; i < p.children.length; i++) {
      var ch = p.children[i];
      if (hasFormControl(ch)) hasCtl = true;
      else { var tt = (ch.textContent || '').trim(); if (tt.length > 0 && tt.length <= 20) hasLabel = true; }
    }
    if (hasLabel && hasCtl) return p;
  }
  return unit;
}
function refineUnit(unit) {
  unit = promoteUnit(unit);
  if (!hasFormControl(unit)) return [unit];
  var prev = unit.previousElementSibling;
  if (prev && !hasFormControl(prev)) {
    var t = (prev.textContent || '').trim();
    if (t.length > 0 && t.length <= 20) return [prev, unit];
  }
  return [unit];
}
function cleanClone(n) {
  var c = n.cloneNode(true);
  c.querySelectorAll('.le-hl').forEach(function(x) { x.classList.remove('le-hl'); x.style.background = ''; });
  c.classList.remove('le-add-unit');
  // v3.7：原节点是 display:contents 时，克隆体必须实体化为纵向容器，
  // 否则子元素会散落到横向父布局里变成横排
  if (window.getComputedStyle(n).display === 'contents') {
    c.style.display = 'flex';
    c.style.flexDirection = 'column';
    c.style.gap = '4px';
    c.style.alignItems = 'stretch';
  }
  return c;
}
// v3.7：多节点克隆（标题+控件散兄弟）包进一个纵向容器，保持上下结构
function wrapClones(clones) {
  if (clones.length <= 1) return clones;
  var w = document.createElement('div');
  w.style.cssText = 'display:flex;flex-direction:column;gap:4px;align-items:stretch;';
  clones.forEach(function(x) { w.appendChild(x); });
  return [w];
}
// 沿所选方向的轴向自动上溯：找到轴向匹配的容器，把整组克隆插入到该容器内对应位置
function insertWithDir(nodes, dir) {
  var axis = (dir === 'left' || dir === 'right') ? 'h' : 'v';
  var outer = nodes[nodes.length - 1];
  // v3.7：先克隆并（多节点时）包成单个纵向容器，保证上下结构不被横向父布局拆散
  var clones = wrapClones(nodes.map(cleanClone));
  var single = clones[0];
  // v3.8 流式插入：当直接父容器是横向布局（如筛选栏）时，无论选哪个方向都留在横向流里
  // 紧贴原单元插入——行没满就待在这行，一行满了靠 flex-wrap 自动错行（用户期望：
  // 向下复制筛选项应贴着筛选、还在同一行；满了自动换行）
  var par = outer.parentElement;
  if (par && containerAxis(par) === 'h') {
    var pcs = window.getComputedStyle(par);
    if (pcs.display.indexOf('flex') !== -1 && pcs.flexWrap === 'nowrap') {
      par.style.flexWrap = 'wrap'; // 保证一行满能自动错行
      par.style.rowGap = '12px';
    }
    if (dir === 'left' || dir === 'up') outer.insertAdjacentElement('beforebegin', single);
    else outer.insertAdjacentElement('afterend', single);
    return clones;
  }
  var cur = outer, hops = 0;
  while (cur.parentElement && cur.parentElement !== document.body && hops < 4) {
    var p = cur.parentElement;
    if (containerAxis(p) === axis) {
      if (dir === 'right' || dir === 'down') cur.insertAdjacentElement('afterend', single);
      else cur.insertAdjacentElement('beforebegin', single);
      return clones;
    }
    cur = p; hops++;
  }
  // 兜底：在整组末尾节点旁直接插入
  if (dir === 'right' || dir === 'down') outer.insertAdjacentElement('afterend', single);
  else outer.insertAdjacentElement('beforebegin', single);
  return clones;
}

function doAddAt(el) {
  if (!el || isLE(el)) return;
  var unit = findUnit(el);
  // v3.6：整页/核心工作区等页面级容器禁止复制
  if (isProtectedUnit(unit)) {
    toast('整个页面/核心工作区不可复制，请选择具体的模块或组件');
    return;
  }
  var nodes = refineUnit(unit);
  var outer = nodes[nodes.length - 1];
  outer.classList.add('le-add-unit');
  closeAddPop();
  addPop = mk('div', 'le-addpop');
  var parent = outer.parentElement;
  var rec = (parent && containerAxis(parent) === 'h') ? 'right' : 'down';
  addPop.innerHTML = '<span class="le-ap-tip">插入方向（推荐' + (rec === 'right' ? '右' : '下') + '）·整组复制</span>' +
    '<button data-dir="up">↑</button><button data-dir="down">↓</button><button data-dir="left">←</button><button data-dir="right">→</button>';
  addPop.querySelector('[data-dir="' + rec + '"]').classList.add('le-rec');
  document.body.appendChild(addPop);
  var r = outer.getBoundingClientRect();
  addPop.style.left = Math.max(8, Math.min(window.innerWidth - 200, r.left)) + 'px';
  addPop.style.top  = Math.max(8, r.bottom + 6) + 'px';
  requestAnimationFrame(function() { addPop && addPop.classList.add('le-show'); });
  addPop.addEventListener('click', function(ev) {
    ev.stopPropagation();
    var b = ev.target.closest('button[data-dir]');
    if (!b) return;
    var dir = b.dataset.dir;
    var clones = insertWithDir(nodes, dir);
    if (clones.length && clones[0].scrollIntoView) clones[0].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    pushUndo({ type: 'add', nodes: clones });
    S.changeLog.push('在「' + elLabel(outer) + '」的' + ({up:'上',down:'下',left:'左',right:'右'})[dir] + '侧新增了一组同类组件（' + nodes.length + ' 个节点的克隆副本）');
    S.structEdits++;
    refreshCount();
    outer.classList.remove('le-add-unit');
    closeAddPop();
    toast('已在' + ({up:'上',down:'下',left:'左',right:'右'})[dir] + '侧整组新增同类项，可点「撤回」恢复');
  });
  setTimeout(function() { if (addPop) closeAddPop(); outer.classList.remove('le-add-unit'); }, 4000);
}

/* ═══════════════════════ v3.2 全局文案校准 ═══════════════════════ */
// 结束文字编辑时：若修改过的文案在页面其他位置还有相同原文，询问是否全局同步
function offerGlobalSync() {
  var edits = [];
  S.textSnaps.forEach(function(snap, nd) {
    if (!nd.isConnected) return;
    var now = (nd.textContent || '').trim().replace(/\s+/g, ' ');
    if (snap.text && now && now !== snap.text) edits.push({ nd: nd, oldT: snap.text, newT: now });
  });
  if (!edits.length) return;
  // 对每条修改，检查页面中是否仍存在相同旧文案的其他节点
  var syncable = [];
  edits.forEach(function(ed) {
    var others = [];
    document.querySelectorAll('body *').forEach(function(nd) {
      if (isLE(nd) || nd === ed.nd) return;
      var t = (nd.textContent || '').trim().replace(/\s+/g, ' ');
      if (t === ed.oldT) others.push(nd);
    });
    if (others.length) syncable.push({ oldT: ed.oldT, newT: ed.newT, nodes: others });
  });
  if (!syncable.length) return;
  var total = syncable.reduce(function(s, x) { return s + x.nodes.length; }, 0);
  var html = '<div class="le-gs"><div class="le-gs-hd">检测到重复文案</div><div class="le-gs-bd">';
  syncable.forEach(function(x) {
    html += '「' + x.oldT + '」已改为 <b>「' + x.newT + '」</b>，页面中还有 <b>' + x.nodes.length + '</b> 处相同旧文案。<br>';
  });
  html += '</div><div class="le-gs-ft"><button class="le-gs-no">仅改此处</button><button class="le-gs-yes">全局同步（' + total + ' 处）</button></div></div>';
  var dlg = mk('div', 'le-gs-wrap');
  dlg.innerHTML = html;
  document.body.appendChild(dlg);
  var panel = dlg.querySelector('.le-gs');
  dlg.querySelector('.le-gs-yes').addEventListener('click', function() {
    var items = [];
    syncable.forEach(function(x) {
      x.nodes.forEach(function(nd) {
        // 仅当节点本身只承载该文案（无其他子元素文本混杂）时才整体替换
        var own = (nd.textContent || '').trim().replace(/\s+/g, ' ');
        if (own === x.oldT) { items.push({ nd: nd, old: x.oldT }); nd.textContent = x.newT; }
      });
    });
    pushUndo({ type: 'sync', items: items }); // v3.3 全局同步可撤回
    S.changeLog.push('全局文案同步：将「' + syncable.map(function(x) { return x.oldT; }).join('、') + '」统一替换为新文案，共 ' + total + ' 处');
    S.structEdits++;
    refreshCount();
    dlg.remove();
    toast('已全局同步 ' + total + ' 处文案，可点「撤回」恢复');
  });
  dlg.querySelector('.le-gs-no').addEventListener('click', function() {
    dlg.remove();
    toast('仅保留当前修改');
  });
}

/* ═══════════════════════ 字号浮标 ═══════════════════════ */
function showBadge(el) {
  clearTimeout(S.fontBadgeTimer);
  var sz = window.getComputedStyle(el).fontSize;
  fbadge.textContent = sz;
  var r = el.getBoundingClientRect();
  var bx = r.right + 8;
  var by = r.top;
  if (bx + 56 > window.innerWidth) bx = r.left - 56;
  if (by < 8) by = 8;
  fbadge.style.left = bx + 'px';
  fbadge.style.top  = by + 'px';
  fbadge.classList.add('le-show');
  S.fontBadgeTimer = setTimeout(hideBadge, 3500);
}
function hideBadge() {
  fbadge.classList.remove('le-show');
  clearTimeout(S.fontBadgeTimer);
}

/* ═══════════════════════ 拖拽排序 ═══════════════════════ */
function doDragToggle() {
  if (S.dragMode) { stopDrag(); bDG.classList.remove('le-on'); }
  else            { exitOtherModes('drag'); startDrag(); bDG.classList.add('le-on'); }
  syncTextEditing();
}

function startDrag() {
  S.dragMode = true;
  S.dragContexts = [];
  // 收集所有可拖拽上下文（包含 ≥2 个子元素的容器）
  // 1) 主容器的直接子元素
  var main = document.querySelector('.page-wrap') || document.body;
  registerCtx(main);
  // 2) 所有 grid / flex 容器（用于卡片拖拽）
  document.querySelectorAll('body *').forEach(function(el) {
    if (isLE(el) || el === main) return;
    var d = window.getComputedStyle(el).display;
    if ((d === 'grid' || d === 'flex' || d === 'inline-grid' || d === 'inline-flex') && el.children.length >= 2) {
      registerCtx(el);
    }
  });
}

function registerCtx(container) {
  var idx = S.dragContexts.length;
  var kids = Array.from(container.children).filter(function(c) {
    if (isLE(c)) return false;
    if (['SCRIPT','STYLE','LINK','META'].indexOf(c.tagName) !== -1) return false;
    return true;
  });
  if (kids.length < 2) return;
  S.dragContexts.push(container);
  kids.forEach(function(mod) {
    mod.classList.add('le-draggable','le-drag-on');
    mod.dataset.leCtx = idx;
    var h = mk('div','le-dh');
    var dots = mk('div','le-dh-dots');
    for (var i = 0; i < 6; i++) dots.appendChild(mk('i'));
    h.appendChild(dots);
    h.appendChild(mk('span','le-tt','按住拖拽换位'));
    mod.insertBefore(h, mod.firstChild);
    S.handles.push(h);
    h.addEventListener('pointerdown', onDragDown);
  });
}

function stopDrag() {
  S.dragMode = false;
  document.querySelectorAll('.le-draggable').forEach(function(m) {
    m.classList.remove('le-draggable','le-drag-on');
    delete m.dataset.leCtx;
  });
  S.handles.forEach(function(h) { h.remove(); });
  S.handles = [];
  S.dragContexts = [];
  cleanDrag();
}

function onDragDown(e) {
  e.preventDefault(); e.stopPropagation();
  var mod = e.target.closest('.le-draggable');
  if (!mod) return;
  var rect = mod.getBoundingClientRect();
  var ctxIdx = parseInt(mod.dataset.leCtx || '0');
  var container = S.dragContexts[ctxIdx] || mod.parentNode;

  // Ghost
  var ghost = mod.cloneNode(true);
  ghost.className = (ghost.className || '').replace(/le-draggable|le-drag-on/g,'').trim();
  ghost.classList.add('le-ghost');
  ghost.style.width  = rect.width + 'px';
  ghost.style.height = rect.height + 'px';
  ghost.style.top    = rect.top + 'px';
  ghost.style.left   = rect.left + 'px';
  ghost.style.margin = '0';
  document.body.appendChild(ghost);

  // Placeholder
  var ph = mk('div','le-ph');
  ph.style.height = rect.height + 'px';
  container.insertBefore(ph, mod);
  mod.style.display = 'none';

  S.dragState = { el: mod, ghost: ghost, ph: ph, oy: e.clientY - rect.top, ox: e.clientX - rect.left, ctx: container };
  document.addEventListener('pointermove', onDragMove);
  document.addEventListener('pointerup', onDragUp);
}

function onDragMove(e) {
  var ds = S.dragState; if (!ds) return;
  ds.ghost.style.top  = (e.clientY - ds.oy) + 'px';
  ds.ghost.style.left = (e.clientX - ds.ox) + 'px';

  var sibs = Array.from(ds.ctx.children).filter(function(c) {
    return (c.classList.contains('le-draggable') && c.style.display !== 'none') || c.classList.contains('le-ph');
  });

  // 判断水平还是垂直布局
  var disp = window.getComputedStyle(ds.ctx).display;
  var isHoriz = (disp === 'flex' || disp === 'inline-flex' || disp === 'grid' || disp === 'inline-grid');
  // 更精确的判断：如果第一个和第二个可见子元素的 top 相近，说明是水平布局
  var visKids = sibs.filter(function(s) { return s !== ds.ph; });
  if (visKids.length >= 2) {
    var r0 = visKids[0].getBoundingClientRect();
    var r1 = visKids[1].getBoundingClientRect();
    isHoriz = Math.abs(r0.top - r1.top) < r0.height * 0.5;
  }

  var placed = false;
  for (var i = 0; i < sibs.length; i++) {
    var sib = sibs[i];
    if (sib === ds.ph) continue;
    var sr = sib.getBoundingClientRect();
    var mid = isHoriz ? (sr.left + sr.width / 2) : (sr.top + sr.height / 2);
    var pos = isHoriz ? e.clientX : e.clientY;
    if (pos < mid) {
      ds.ctx.insertBefore(ds.ph, sib);
      placed = true;
      break;
    }
  }
  if (!placed) {
    var last = sibs[sibs.length - 1];
    if (last && last !== ds.ph) ds.ctx.insertBefore(ds.ph, last.nextSibling);
  }
}

function onDragUp() {
  var ds = S.dragState; if (!ds) return;
  ds.ph.parentNode.insertBefore(ds.el, ds.ph);
  ds.el.style.display = '';
  ds.ghost.remove();
  ds.ph.remove();
  S.dragState = null;
  document.removeEventListener('pointermove', onDragMove);
  document.removeEventListener('pointerup', onDragUp);
  S.changeLog.push('拖拽移动了模块「' + elLabel(ds.el) + '」的位置');
  S.structEdits++;
  refreshCount();
}

function cleanDrag() {
  if (S.dragState) {
    if (S.dragState.ghost) S.dragState.ghost.remove();
    if (S.dragState.ph) S.dragState.ph.remove();
    if (S.dragState.el) S.dragState.el.style.display = '';
    S.dragState = null;
  }
  document.removeEventListener('pointermove', onDragMove);
  document.removeEventListener('pointerup', onDragUp);
}

function bumpEdit() {
  if (S.activeEl) S.editedEls.add(S.activeEl);
  else S.structEdits++;
  refreshCount();
}

/* ═══════════════════════ v4.0 直接操纵：悬停操作条 ═══════════════════════ */
/* 悬停模块浮出操作条（⋮⋮拖动 / ⧉复制 / ✕删除），零模式切换；
   复用 promoteUnit / refineUnit / insertWithDir / pushUndo / changeLog / 容器保护；
   任一 legacy 模式（拖拽/换图/新增/删除）激活时操作条自动隐藏，二者共存。 */
var hoverBar = null, hoverUnit = null, v4drag = null;
S._v4armed = null;

function buildHoverBar() {
  if (hoverBar) return;
  hoverBar = mk('div', 'le-hb');
  var bDrag = mk('button', '', '⋮⋮<span class="le-tt">拖动换位</span>');
  var bCopy = mk('button', '', '⧉<span class="le-tt">复制</span>');
  var bDel  = mk('button', 'le-hb-del', '✕<span class="le-tt">删除（点两次确认）</span>');
  bDrag.addEventListener('pointerdown', hbDragStart);
  bCopy.addEventListener('click', function(e) { e.stopPropagation(); hbCopy(); });
  bDel.addEventListener('click', function(e) { e.stopPropagation(); hbDelete(); });
  hoverBar.appendChild(bDrag); hoverBar.appendChild(bCopy); hoverBar.appendChild(bDel);
  hoverBar.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
  hoverBar.addEventListener('click', function(e) { e.stopPropagation(); });
  document.body.appendChild(hoverBar);
}
function hbVisible() { return hoverBar && hoverBar.classList.contains('le-show'); }
function hideHoverBar() {
  if (hoverBar) hoverBar.classList.remove('le-show');
  if (hoverUnit) { hoverUnit.classList.remove('le-hb-unit'); hoverUnit = null; }
  disarmDelete();
}
function positionHoverBar(r) {
  var bw = hoverBar.offsetWidth || 96, bh = hoverBar.offsetHeight || 32;
  var left, top;
  // v2.1.3 自适应定位：
  // ① 大模块（装得下操作条且留有余量）：放在模块内侧右上角，不越出上边缘；
  // ② 小模块（按钮/小卡片等）：外置到模块上方（右对齐），绝不压住模块自身的文案，
  //    保证模块内的文字仍可点击编辑。外置安全由悬停锁定 + 高 z-index + 事件拦截保证。
  var fitsInside = (r.width >= bw + 20) && (r.height >= bh + 16);
  if (fitsInside) {
    left = r.right - bw - 6;
    top = r.top + 6;
  } else {
    // 外置：优先模块上方（右对齐）；上方空间不足时改放下方
    left = r.right - bw;
    top = r.top - bh - 6;
    if (top < 8) top = r.bottom + 6;
    // 下方也放不下（极端情况）：退回内侧贴右上角
    if (top + bh > window.innerHeight - 8) { left = r.right - bw - 6; top = Math.max(8, r.top); }
  }
  // 视口边界收敛。
  left = Math.max(8, Math.min(left, window.innerWidth - bw - 8));
  top = Math.max(8, Math.min(top, window.innerHeight - bh - 8));
  hoverBar.style.left = left + 'px';
  hoverBar.style.top = top + 'px';
}
function showHoverBarFor(unit) {
  buildHoverBar();
  if (hoverUnit && hoverUnit !== unit) hoverUnit.classList.remove('le-hb-unit');
  hoverUnit = unit;
  unit.classList.add('le-hb-unit');
  positionHoverBar(unit.getBoundingClientRect());
  hoverBar.classList.add('le-show');
}
function hoverBarAllowed() {
  // 注意：不能检查 S.editing —— 编辑器打开时 S.editing 恒为 true（文本可编辑是常态），
  // 悬停操作条恰恰要在文本编辑常态下工作，靠按钮 stopPropagation 与文字编辑共存。
  // v2.1.2：额外排除两类冲突场景——
  //   ① 任一浮层/弹窗打开时（换色/样式/间距/换图/编辑记录/全局同步），不弹操作条，避免叠在浮层上；
  //   ② 光标正聚焦在可编辑文本里（用户正在输入）时不弹操作条，避免干扰打字。
  return S.open && !anyStructMode() && !S.dragState && !v4drag && !addPop
         && !anyOverlayOpen() && !isTextFocused();
}
/* v2.1.2：是否有浮层/弹窗处于打开状态 */
function anyOverlayOpen() {
  if (cpanel && cpanel.classList.contains('le-show')) return true;   // 换色面板
  if (spanel && spanel.classList.contains('le-show')) return true;   // 样式面板
  if (spcPanel) return true;                                          // 间距面板
  if (imgPanel) return true;                                          // 换图面板
  if (document.querySelector('.le-mbg')) return true;                 // 编辑记录弹窗
  if (document.querySelector('.le-gs')) return true;                  // 全局文案同步弹窗
  return false;
}
/* v2.1.2：光标是否正聚焦在可编辑文本内（用实时 activeElement 判断，比缓存的 S.activeEl 更准） */
function isTextFocused() {
  var ae = document.activeElement;
  return !!(ae && ae.closest && ae.closest('.le-editable'));
}
var hbHideTimer = null;
function cancelHbHide() { if (hbHideTimer) { clearTimeout(hbHideTimer); hbHideTimer = null; } }
function scheduleHbHide() {
  cancelHbHide();
  hbHideTimer = setTimeout(function() { if (!hoverBarAllowed()) return; hideHoverBar(); }, 260);
}
/* 指针是否落在操作条的命中盒内（外扩 10px 容错）——是则锁定当前模块，不重新瞄准，
   避免鼠标移向操作条途中被上方/相邻模块抢走焦点导致"点不中"。 */
function pointerOnHoverBar(cx, cy) {
  if (!hoverBar || !hbVisible()) return false;
  var r = hoverBar.getBoundingClientRect();
  return cx >= r.left - 10 && cx <= r.right + 10 && cy >= r.top - 10 && cy <= r.bottom + 10;
}
document.addEventListener('mouseover', function(e) {
  if (!hoverBarAllowed()) { if (hbVisible()) hideHoverBar(); return; }
  var t = e.target;
  if (!t || t.nodeType !== 1) return;
  // 鼠标在操作条上：保持显示，取消隐藏计时
  if (isLE(t)) { if (hoverBar && hoverBar.contains(t)) { cancelHbHide(); return; } if (hbVisible()) hideHoverBar(); return; }
  // 锁定：指针仍在操作条命中盒内（正移向按钮），不重新瞄准、不隐藏
  if (pointerOnHoverBar(e.clientX, e.clientY)) { cancelHbHide(); return; }
  var unit = promoteUnit(findUnit(t));
  if (!unit || unit === document.body || isProtectedUnit(unit)) {
    // 离开有效单元：给一段宽限期（便于移向悬浮的操作条），超时再隐藏
    if (hbVisible()) scheduleHbHide();
    return;
  }
  cancelHbHide();
  if (unit === hoverUnit && hbVisible()) return;
  disarmDelete();
  showHoverBarFor(unit);
}, true);

/* v2.1.2：光标聚焦进可编辑文本时立即收起操作条 —— 打字/选词期间不弹浮层干扰输入。 */
document.addEventListener('focusin', function(e) {
  if (e.target && e.target.closest && e.target.closest('.le-editable') && hbVisible()) hideHoverBar();
}, true);
/* v2.1.2：页面滚动/窗口缩放时收起操作条 —— 操作条是 fixed 定位、位置只在显示时计算一次，
   页面一动它就与模块错位，与其错位悬浮不如先收起，鼠标重新悬停时再出现。 */
window.addEventListener('scroll', function() { if (hbVisible()) hideHoverBar(); }, true);
window.addEventListener('resize', function() { if (hbVisible()) hideHoverBar(); }, true);

/* ── v4.0 直接拖动（操作条 ⋮⋮ 按下即拖，无需开拖拽模式）── */
function hbDragStart(e) {
  if (!hoverUnit) return;
  e.preventDefault(); e.stopPropagation();
  exitOtherModes();
  var unit = hoverUnit;
  hideHoverBar();
  stopEditing(true);
  var parent = unit.parentElement;
  if (!parent) return;
  // v2.1.2：记录拖动前的原始位置，供 ↩ 撤回移动（与删除/新增一致）
  var origParent = parent;
  var origNext = unit.nextSibling;
  var rect = unit.getBoundingClientRect();
  var ghost = unit.cloneNode(true);
  ghost.className = (ghost.className || '').replace(/le-hb-unit/g, '').trim();
  ghost.classList.add('le-ghost');
  ghost.style.width = rect.width + 'px';
  ghost.style.height = rect.height + 'px';
  ghost.style.top = rect.top + 'px';
  ghost.style.left = rect.left + 'px';
  ghost.style.margin = '0';
  document.body.appendChild(ghost);
  var ph = mk('div', 'le-ph');
  ph.style.height = rect.height + 'px';
  parent.insertBefore(ph, unit);
  unit.style.display = 'none';
  var sibs = Array.from(parent.children).filter(function(c) {
    return !isLE(c) && ['SCRIPT','STYLE','LINK','META'].indexOf(c.tagName) === -1;
  });
  sibs.forEach(function(c) { c.classList.add('le-draggable'); });
  v4drag = { el: unit, ghost: ghost, ph: ph, ctx: parent, sibs: sibs, oy: e.clientY - rect.top, ox: e.clientX - rect.left, origParent: origParent, origNext: origNext };
  // 指针捕获：拖动全程不丢指针事件，划过其他元素也不会中断
  if (e.target && e.target.setPointerCapture) { try { e.target.setPointerCapture(e.pointerId); } catch (err) {} }
  document.addEventListener('pointermove', hbDragMove);
  document.addEventListener('pointerup', hbDragUp);
  document.addEventListener('pointercancel', hbDragUp);
}
function hbDragMove(e) {
  var d = v4drag; if (!d) return;
  d.ghost.style.top = (e.clientY - d.oy) + 'px';
  d.ghost.style.left = (e.clientX - d.ox) + 'px';
  var sibs = d.sibs.filter(function(c) { return c !== d.el && c.style.display !== 'none'; }).concat([d.ph]);
  // 判断水平还是垂直布局：前两个可见子元素 top 相近 → 水平
  var visKids = sibs.filter(function(s) { return s !== d.ph; });
  var isHoriz = false;
  if (visKids.length >= 2) {
    var r0 = visKids[0].getBoundingClientRect();
    var r1 = visKids[1].getBoundingClientRect();
    isHoriz = Math.abs(r0.top - r1.top) < r0.height * 0.5;
  }
  var placed = false;
  for (var i = 0; i < sibs.length; i++) {
    var sib = sibs[i];
    if (sib === d.ph) continue;
    var sr = sib.getBoundingClientRect();
    var mid = isHoriz ? (sr.left + sr.width / 2) : (sr.top + sr.height / 2);
    var pos = isHoriz ? e.clientX : e.clientY;
    if (pos < mid) { d.ctx.insertBefore(d.ph, sib); placed = true; break; }
  }
  if (!placed) {
    var last = sibs[sibs.length - 1];
    if (last && last !== d.ph) d.ctx.insertBefore(d.ph, last.nextSibling);
  }
}
function hbDragUp(e) {
  var d = v4drag; if (!d) return;
  d.ph.parentNode.insertBefore(d.el, d.ph);
  d.el.style.display = '';
  d.ghost.remove();
  d.ph.remove();
  d.sibs.forEach(function(c) { c.classList.remove('le-draggable'); });
  document.removeEventListener('pointermove', hbDragMove);
  document.removeEventListener('pointerup', hbDragUp);
  document.removeEventListener('pointercancel', hbDragUp);
  if (e && e.target && e.target.releasePointerCapture) { try { e.target.releasePointerCapture(e.pointerId); } catch (err) {} }
  v4drag = null;
  // v2.1.2 修复：拖拽开始时 stopEditing 移除了全页 contenteditable 与监听器，
  // 结束后必须恢复，否则文本编辑功能永久失效（用户报告的核心缺陷）。
  // fresh=false：保留已有的 textSnaps/changeLog 记录，不重置。
  if (S.open) startEditing(false);
  // v2.1.2：位置真的变了才记录（原地放下不算操作），并入撤回栈（move 类型）
  if (d.el.parentElement !== d.origParent || d.el.nextSibling !== d.origNext) {
    pushUndo({ type: 'move', node: d.el, origParent: d.origParent, origNext: d.origNext });
    S.changeLog.push('拖拽移动了模块「' + elLabel(d.el) + '」的位置');
    S.structEdits++;
    refreshCount();
    toast('已移动，可点 ↩ 撤回');
  }
}

/* ── v4.0 复制（复用新增模式的方向弹窗 doAddAt）── */
function hbCopy() {
  if (!hoverUnit) return;
  var unit = hoverUnit;
  hideHoverBar();
  doAddAt(unit);
}

/* ── v4.0 删除（点两次确认，复用撤回栈）── */
function disarmDelete() {
  if (S._v4armed && S._v4armed.btn) S._v4armed.btn.classList.remove('le-armed');
  if (S._v4armTimer) clearTimeout(S._v4armTimer);
  S._v4armed = null;
}
function hbDelete() {
  if (!hoverUnit) return;
  var unit = hoverUnit;
  var delBtn = hoverBar ? hoverBar.querySelector('.le-hb-del') : null;
  if (S._v4armed && S._v4armed.unit === unit) {
    var parent = unit.parentElement, next = unit ? unit.nextSibling : null;
    var label = elLabel(unit);
    unit.remove();
    disarmDelete();
    hideHoverBar();
    pushUndo({ type: 'del', node: unit, parent: parent, next: next });
    S.changeLog.push('删除了组件/模块「' + label + '」');
    S.structEdits++;
    refreshCount();
    toast('已删除「' + label + '」，可点 ↩ 撤回');
  } else {
    disarmDelete();
    S._v4armed = { unit: unit, btn: delBtn };
    if (delBtn) delBtn.classList.add('le-armed');
    toast('再点一次 ✕ 确认删除');
    S._v4armTimer = setTimeout(disarmDelete, 3000);
  }
}

/* ═══════════════════════ 编辑记录弹窗 ═══════════════════════ */
function getElLocation(el) {
  var sections = Array.from(document.querySelectorAll('.page-wrap > *')).filter(function(c) { return !isLE(c); });
  var sec = el.closest('section, header, footer, [class*="section"], .page-header, .page-wrap > *');
  var secIdx = sec ? sections.indexOf(sec) + 1 : 0;
  var secLabel = secIdx > 0 ? 'Section ' + (secIdx < 10 ? '0' : '') + secIdx : 'Page';
  var elId = '';
  if (el.className) {
    var cls = el.className.split(' ').filter(function(c) { return c && !c.startsWith('le-'); });
    elId = cls[0] || '';
  }
  if (!elId) elId = el.tagName.toLowerCase();
  return secLabel + ' / ' + elId;
}

function collectChanges() {
  var list = [];
  // 文字修改（对比快照）
  S.textSnaps.forEach(function(snap, el) {
    var cur = el.textContent.trim().replace(/\s+/g,' ');
    if (cur !== snap.text) {
      list.push({ type:'text', loc: getElLocation(el), oldText: snap.text, newText: cur });
    }
  });
  // 样式/结构操作
  S.changeLog.forEach(function(entry) {
    list.push({ type:'style', loc:'样式修改', desc: entry });
  });
  return list;
}

function buildPrompt(changes) {
  var lines = [];
  changes.forEach(function(c) {
    if (c.type === 'text') {
      var o = c.oldText.length > 30 ? c.oldText.substring(0,30) + '…' : c.oldText;
      var n = c.newText.length > 30 ? c.newText.substring(0,30) + '…' : c.newText;
      lines.push('将文字「' + o + '」改为「' + n + '」');
    } else {
      lines.push(c.desc);
    }
  });
  var prompt = '请根据以下修改更新页面：\n\n';
  for (var i = 0; i < lines.length; i++) prompt += (i+1) + '. ' + lines[i] + '\n';
  return prompt;
}

function showSaveModal() {
  var changes = collectChanges();
  if (changes.length === 0) { toast('暂无修改'); return; }

  // 遮罩
  var bg = mk('div','le-mbg');
  var md = mk('div','le-md');

  // 头部
  var hd = mk('div','le-md-hd');
  var hdL = mk('div','le-md-hd-l');
  hdL.innerHTML = '<h3>编辑记录</h3><p>共 ' + changes.length + ' 处修改</p>';
  var hdR = mk('div','le-md-hd-r');
  var copyBtn = mk('button','le-md-copy','复制 Prompt');
  var clsBtn = mk('button','le-md-cls','关闭');
  hdR.append(copyBtn, clsBtn);
  hd.append(hdL, hdR);
  md.appendChild(hd);

  // 变更列表
  var body = mk('div','le-md-body');
  changes.forEach(function(c, i) {
    var card = mk('div','le-chg');
    card.appendChild(mk('div','le-chg-hd', (i+1) + '. ' + c.loc));
    if (c.type === 'text') {
      var diff = mk('div','le-chg-diff');
      diff.appendChild(mk('div','le-chg-old', c.oldText));
      diff.appendChild(mk('span','le-chg-arr','→'));
      diff.appendChild(mk('div','le-chg-new', c.newText));
      card.appendChild(diff);
    } else {
      card.appendChild(mk('div','le-chg-desc', c.desc));
    }
    body.appendChild(card);
  });
  md.appendChild(body);

  // 底部
  md.appendChild(mk('div','le-md-ft','复制 Prompt 后发给 Claude，即可自动更新源文件。'));

  bg.appendChild(md);
  document.body.appendChild(bg);
  requestAnimationFrame(function() {
    requestAnimationFrame(function() { bg.classList.add('le-show'); });
  });

  // 复制
  copyBtn.addEventListener('click', function() {
    var prompt = buildPrompt(changes);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(prompt).then(function() {
        copyBtn.textContent = '已复制';
        copyBtn.classList.add('le-copied');
      }).catch(function() { fallbackCopy(prompt, changes.length); copyBtn.textContent = '已复制'; copyBtn.classList.add('le-copied'); });
    } else {
      fallbackCopy(prompt, changes.length);
      copyBtn.textContent = '已复制';
      copyBtn.classList.add('le-copied');
    }
  });
  // 关闭
  function closeM() {
    bg.classList.remove('le-show');
    setTimeout(function() { bg.remove(); }, 300);
  }
  clsBtn.addEventListener('click', closeM);
  bg.addEventListener('click', function(e) { if (e.target === bg) closeM(); });
}
function fallbackCopy(text, count) {
  var ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;left:-9999px';
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  ta.remove();
  toast('✓ 已复制 ' + count + ' 条修改指令，粘贴给AI即可');
}

})();
