# Live Edit Round-trip Rules (Live Edit 编辑回传闭环)

> v0.8.5 — closes the loop: user edits the generated page in-browser via Live Edit v3.0 → copies the change Prompt → sends it back → the agent applies the edits to the source file.
>
> v0.8.23 — Live Edit upgraded to **v3.2**, adding three capabilities: 模块删除 (delete), 同类项新增 (duplicate/add), 全局文案校准 (global text sync).
>
> v0.8.24 — Live Edit upgraded to **v3.3**: delete becomes a hover red ✕ corner badge with two-click confirm; the four structural modes (拖拽/换图/新增/删除) are mutually exclusive and pause text-editing while active; a「↩ 撤回」undo button sits after the「N处」counter and can revert delete/add/image-replace/text/global-sync; image replace now also works on placeholder slots (div background-image / inline-SVG placeholders like product-image blocks); add-mode clones the full sibling unit (findUnit) and asks insert direction 上/下/左/右 with layout-aware recommendation.
>
> v0.8.25 — Live Edit upgraded to **v3.4** (two bugfix streams): ① image-replace mode gains hover purple outline on the target (img or placeholder slot) before clicking; slot detection hardened — page-level containers (>600px wide / >50% viewport / body direct children) are rejected as replace targets both at detection and at apply time (fixes the "uploaded image painted the whole page background" defect); gray placeholder blocks are now recognized as slots; upward walk tightened 4→3 hops with IMG priority. ② delete mode: fixed the ✕ badge flicker loop (hovering the badge no longer recomputes the unit); double-clicking the module still deletes, and all toasts now state both confirm paths (点红色✕ / 双击模块); armed-state wording matches actual behavior.
>
> v0.8.26 — Live Edit upgraded to **v3.5** (interaction overhaul per user feedback): ① delete mode drops the floating ✕ badge entirely (the flicker source) — now hover shows a red outline and **double-click deletes**; first click arms with a toast explaining the double-click. ② add mode: filter-group awareness — clicking a form control whose previous sibling is a short text label (e.g. 「商品名称/商品ID」) groups [label + control] as ONE copy unit; direction insertion now walks UP along the chosen axis (containerAxis) so 右 inserts the whole group to the right of the row, 下 inserts the whole row below — no more silent direction conversion that made 右/左 land below.
>
> v0.8.27 — Live Edit upgraded to **v3.6**: page-level container protection. The whole page / core workspace (body direct children, >90% viewport wide, >80% viewport tall, main scroll container) can be NEITHER deleted NOR duplicated; delete-mode hover shows no red outline on them and double-click refuses with a toast.
>
> v0.8.29 — Live Edit upgraded to **v3.8**: flow-style insertion for horizontal parents. When the cloned unit's DIRECT parent is a horizontal container (e.g. a filter bar), any direction choice (including 上/下) keeps the clone in that horizontal flow right next to the original item — same row while the row has room, and when the row is full it wraps automatically (the container is switched from flex-wrap:nowrap to wrap + row-gap 12px on the fly). Fixes the reported「向下复制筛选跑到了整个筛选区下面」defect: 向下复制现在贴着原筛选项留在同一行，一行满自动错行.
>
> v0.8.28 — Live Edit upgraded to **v3.7**: filter-group clones keep their vertical structure. promoteUnit: when the clicked control/label lives in a small vertical wrapper (≤4 children, vertical axis) containing both a short text label and a form control, the WHOLE wrapper becomes the copy/delete unit — the clone preserves the top-label/bottom-control layout instead of being split into two horizontal siblings. Delete mode outlines/removes the whole wrapper too. Additionally, cleanClone materializes any `display:contents` clone into a real flex-column container, and multi-node clones are wrapped in a vertical container (wrapClones) before insertion — this fixes the reported「复制出来成横向」defect where contents-wrappers scattered their children into the horizontal filter bar.

## Live Edit capability matrix (v4.0)

| 能力 | 工具栏按钮 | 说明 | 首次引入 |
|------|-----------|------|---------|
| 文字修改 | 直接点击编辑 | 点击任意文字即改 | v3.0 |
| 换色 | 色块 | 选中元素换文字/背景色 | v3.0 |
| 字号 A-/A+ | 字号按钮 | 选中元素调字号 | v3.0 |
| 高亮 / 居中 | 高亮/居中 | 标记与对齐 | v3.0 |
| 分割线 | 分割线 | 在元素下方插入 | v3.0 |
| 拖拽排序 | 拖拽 | 拖动模块/卡片换位置 | v3.0 |
| 图片替换 | 换图 | 上传/粘贴 URL 换图 | v3.1 |
| 间距调整 | 间距 | ±4px 调 padding/margin | v3.1 |
| **模块删除** | **删除** | 悬停模块显示红描边，**双击模块即删**（无浮动图标，v3.5 彻底去除闪烁源）；Esc 退出 | **v3.2→v3.5** |
| **同类项新增** | **新增** | 点击筛选项/选项卡/卡片，选 上/下/左/右 插入克隆副本；筛选组（标题+控件的纵向 wrapper）整体复制且保持上下结构（v3.7）；**横向容器内复制走流式插入——贴着原项同行，一行满自动错行**（v3.8）；方向沿轴向自动上溯插入（v3.5） | **v3.2→v3.8** |
| **全局文案校准** | 自动 | 文字修改后自动检测全页相同旧文案，弹窗询问是否一键全局同步 | **v3.2** |
| **撤回** | **↩ 撤回** | 「N处」计数后的撤回按钮：可撤回删除/新增/换图/文字/全局同步 | **v3.3** |
| **占位图换图** | 换图 | 换图模式悬停目标显示紫色描边；支持占位图槽（灰色占位块/背景图/SVG 占位）；页面级容器护栏，杜绝误贴整页背景 | **v3.3→v3.4** |
| **模式互斥** | — | 拖拽/换图/新增/删除 一次只能开一个；开启时暂停文本编辑，退出恢复 | **v3.3** |
| **悬停操作条（直接操纵）** | 悬停浮出 | 悬停模块在右上角浮出操作条：⋮⋮ 拖动换位（按下即拖，无需开拖拽模式，**可 ↩ 撤回**）、⧉ 复制（复用方向弹窗）、✕ 删除（点两次确认）。零模式切换、所见即所操作；复用 promoteUnit/insertWithDir/pushUndo/容器保护，全部进撤回栈与编辑记录。任一 legacy 模式激活、任一浮层打开、正在输入文本、页面滚动/缩放时操作条自动隐藏；拖拽结束自动恢复文本编辑 | **v4.0（2.1.1/2.1.2 修复）** |
| **页面级容器保护** | — | 整页/核心工作区（body 直接子级、>90% 视口宽、>80% 视口高、主滚动容器）不可删除、不可复制，悬停不显示红描边（v3.6） | **v3.6** |

All structural edits (删除/新增/全局同步) are recorded into the change log and included in the exported Prompt, so the round-trip loop below applies to them as well.

## The loop

```text
generated page (with Live Edit injected)
  → user drags the ✏️ button to a comfortable spot, opens the toolbar
  → user edits text / colors / font sizes / highlights / dividers / module order
  → user clicks 保存 → 编辑记录 modal → 复制 Prompt
  → user pastes the Prompt back to the agent
  → agent applies the changes to the source HTML file   ← THIS DOCUMENT GOVERNS THIS STEP
  → agent re-injects Live Edit and confirms
```

## Recognizing a round-trip message

A Live Edit round-trip Prompt typically contains a structured change list such as:

- `文字修改：「旧文案」→「新文案」` (one entry per text edit, old → new)
- `颜色修改：元素 xxx 的颜色 #AAA → #BBB`
- `字号修改：元素 xxx 的字号 14px → 16px`
- `高亮 / 分割线 / 模块排序` entries
- `删除了组件/模块「xxx」` (v3.2 — remove that block from the source)
- `在「xxx」之后新增了一个同类组件（克隆副本）` (v3.2 — duplicate that block after the original)
- `全局文案同步：将「旧文案」统一替换为新文案，共 N 处` (v3.2 — replace every occurrence in the source)

**Recognition rule**: if the incoming user message is a list of visual micro-edits to a page that this workflow already generated (text/color/font/highlight/divider/reorder), treat it as a **Live Edit round-trip**, NOT as a new page request.

## What a round-trip is NOT

A round-trip is a **micro-adjustment within the same workflow**. It must NOT trigger:

- ❌ Re-running requirement questions — the business decisions are unchanged.
- ❌ Re-rendering a design plan or asking `继续执行 / 调整设计计划 / 停止执行` again — the plan (if any) is already approved and executed.
- ❌ Regenerating the whole page from scratch — apply the diff only.

If the message instead asks for new modules, structural changes, or different business content, it is a **revision request** (调整), not a round-trip — handle it as a normal follow-up, reusing the existing page structure where possible.

## Applying the changes

1. **Locate the source file**: the page generated in this workflow (e.g. the single-file HTML). If ambiguous, ask which file once.
2. **Apply each change as a targeted edit** to the source markup/CSS:
   - Text: replace the exact old string with the new one.
   - Color: update the element's `color` / `background` value.
   - Font size: update `font-size`.
   - Highlight: wrap/unwrap the target text in the highlight style used by the page.
   - Divider: insert/remove an `<hr>`-style divider element at the recorded position.
   - Reorder: move the module block to the new position among its siblings.
3. **Do NOT touch anything the user did not change.** The rest of the page stays byte-identical.
4. **Re-inject Live Edit v4.0** before `</body>` (verbatim from `assets/live-edit-v4.js`) so the page remains editable for the next round. If the script is already present and intact, leave it as-is — it self-guards against double injection via `data-le-v3`.
5. **Keep token discipline**: if a user-chosen color is outside `tokens/antd-theme-token.json`, still apply it (the user's explicit edit wins), but note in the reply that it is a custom value.

## Reply format

After applying, reply in 简体中文 with a short confirmation:

```text
已应用 N 处修改：
- 文字：「旧」→「新」 ✓
- 颜色：xxx ✓
…
页面已更新并保留实时编辑能力，可继续在浏览器中调整。
```

Do not re-output the design plan, do not re-ask questions, do not append a new `继续执行` choice.

## Edge cases

| Case | Handling |
|------|----------|
| Old text not found in source (page drifted) | Apply the closest match by context; if impossible, list the unmatched entries and ask the user to confirm the target element once |
| Conflicting edits (same element edited twice) | Last entry wins |
| Edit targets an element inside a chart (SVG) | Apply to the SVG's text/fill attributes; charts are part of the page DOM |
| User sends the Prompt but the source file is gone | Regenerate the page from the delivered result first, then apply the edits |
