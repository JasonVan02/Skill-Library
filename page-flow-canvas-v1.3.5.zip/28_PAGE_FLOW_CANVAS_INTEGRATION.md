# Page-Flow Canvas Integration (画布接入 · v1.0.0)

> v1.0.0 — 多页面交付增强：本 skill 内置 page-flow-canvas（v1.3.4），为同一需求生成 ≥2 个页面时必须组装页面流转画布。**画布组装在线上发布之后进行。**

## 触发条件

同一需求产出 **2 个及以上相关页面** → 必须组装画布；单页面不调用。

## 时序（与发布流程的关系）

```text
全部页面生成 + Live Edit 注入完毕
  → ① 发布询问（是/否）→ 是则自动 page-publish（见 docs/27）
  → ② 组装画布（本文件）→ 本地交付
```

先线上、后画布：发布只依赖页面文件，画布不依赖发布。两者互不阻塞——发布失败照常组画布，画布问题不影响已发布链接。

## 组装步骤（内置套件）

套件已内置于 `assets/page-flow-canvas/`（scripts/scan.js、scripts/inject.js、template/canvas-template.html、examples/example-input.json），完整输入契约与字段说明见 `assets/page-flow-canvas/CANVAS.md`。

```bash
# 1. 扫描组装 input.json 草稿（自动推导跨页流转，再人工核定 main / via）
node <本skill目录>/assets/page-flow-canvas/scripts/scan.js <页面目录> input.json --infer-flows --title <需求名>

# 2. 注入生成画布
node <本skill目录>/assets/page-flow-canvas/scripts/inject.js input.json <输出目录>/<需求名>-页面流转画布.html
```

注意：
- scan.js 自动排除画布产物（文件名含「画布/canvas」或内容含 page-flow-canvas@ 标记），重复扫描幂等。
- inject.js 自带输入校验（id 合法性/引用完整性/HTML 完整性），失败输出逐条错误，修正 input.json 后重跑。
- 页面 HTML 中的 `</script>` 由脚本自动转义，无需预处理。
- trigger 写法：好——点击「立即报名」；差——跳转下一页。主路径 main:true 按操作先后排列，旁路 main:false。
- 页面数 > 6 时提醒用户画布较大，建议按子流程拆分出图。

## 交付要求

画布 HTML 与各页面文件一并本地交付，并附一句话流转关系摘要（主路径 + 分支）。

## 画布是否发布（预留位）

**当前版本：画布仅本地交付，不发布。** 原因：画布是自包含单文件（所有页面 HTML 已内嵌），是否发布由用户后续决定；流程结构已预留——将来若决定发布画布，在画布组装完成后**独立追加一次发布**即可，不影响已发布的页面链接，无需重构流程。

## 回炉后的画布同步（重要）

画布内嵌的是页面**组装时刻的快照**。任一页面经 Live Edit 回炉更新源文件后，**必须重新组装画布**（重跑 scan + inject），保证画布与最新源文件一致。重建属于本地交付的自动同步，不重复询问用户；画布重建后再按 docs/27 的再发布流程处理线上更新。

## 边界

- 画布不生成页面；页面由本 skill 生成后交给画布组装。
- 画布内编辑（连线/便签/拖拽节点）通过「导出 input.json 回炉再生」闭环，与 Live Edit 回传是两条独立链路。
- 画布运行依赖 CDN（React Flow / elkjs / JSZip），产物需联网打开——公网链接场景本来就联网，无影响。
