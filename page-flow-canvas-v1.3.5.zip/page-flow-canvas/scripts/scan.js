#!/usr/bin/env node
/**
 * scan.js — 扫描页面目录，自动组装 input.json 草稿（v1.2 新增）
 *
 * 用法：
 *   node scan.js <页面目录> [输出input.json|-] [--infer-flows] [--title 标题] [--prd-id 编号] [--logo 单字]
 *
 * 行为：
 *   1. 扫描目录下所有 .html（自动排除画布产物：文件名含「画布/canvas」或内容含 page-flow-canvas@ 标记）
 *   2. 按文件名中的数字自然排序（p1-xx < p2-xx < ...），生成 pages[] 草稿
 *      - id 取自文件名（净化为字母/数字/_/-），title 取自 <title> 首段，首个页面自动标 core
 *   3. --infer-flows：扫描每个页面 HTML 中的跨页跳转意图（如 toast('跳转到 P2 任务中心')），
 *      按「文件名数字 = 页码」映射生成 flows[] 草稿（main:false，需人工核定主路径与 via）
 *   4. 输出 input.json 草稿（默认 ./input-draft.json，- 表示 stdout）
 */
'use strict';
const fs = require('fs');
const path = require('path');

const VERSION = '1.3.5';

const argv = process.argv.slice(2);
const flags = { inferFlows: false, title: null, prdId: null, logo: null };
const positional = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--infer-flows') flags.inferFlows = true;
  else if (a === '--title') flags.title = argv[++i];
  else if (a === '--prd-id') flags.prdId = argv[++i];
  else if (a === '--logo') flags.logo = argv[++i];
  else if (a === '-h' || a === '--help') { help(); process.exit(0); }
  else positional.push(a);
}

function help() {
  console.log([
    '用法: node scan.js <页面目录> [输出input.json|-] [--infer-flows] [--title 标题] [--prd-id 编号] [--logo 单字]',
    '',
    '  <页面目录>        存放页面 HTML 的目录（画布产物会被自动排除）',
    '  [输出|-]          草稿输出路径，默认 ./input-draft.json；- 表示 stdout',
    '  --infer-flows     扫描页面内的「跳转到 PX」等跨页意图，生成 flows[] 草稿',
    '  --title/--prd-id/--logo  画布元信息（可选）',
  ].join('\n'));
}

const dir = positional[0];
if (!dir) { console.error('❌ 缺少参数：<页面目录>。用 --help 查看用法'); process.exit(1); }
const outArg = positional[1] || 'input-draft.json';
const toStdout = outArg === '-';
const log = (...a) => (toStdout ? process.stderr.write(a.join(' ') + '\n') : console.log(...a));

if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
  console.error('❌ 目录不存在或不是目录: ' + dir);
  process.exit(1);
}

/* ---------------- 扫描与过滤 ---------------- */
const isCanvasArtifact = (name, content) =>
  /画布|canvas/i.test(name) || content.includes('page-flow-canvas@');

const entries = fs.readdirSync(dir)
  .filter(n => /\.html?$/i.test(n))
  .map(n => {
    const content = fs.readFileSync(path.join(dir, n), 'utf8');
    return { name: n, content };
  })
  .filter(f => !isCanvasArtifact(f.name, f.content));

if (!entries.length) {
  console.error('❌ 目录下没有找到页面 HTML（画布产物已自动排除）: ' + dir);
  process.exit(1);
}

/* 自然排序：按文件名中首个数字，其次按名称 */
const numKey = (n) => { const m = n.match(/\d+/); return m ? parseInt(m[0], 10) : Infinity; };
entries.sort((a, b) => (numKey(a.name) - numKey(b.name)) || a.name.localeCompare(b.name));

/* ---------------- 生成 pages[] ---------------- */
const seenIds = new Set();
const pages = entries.map((f, i) => {
  const base = f.name.replace(/\.html?$/i, '');
  let id = base.replace(/[^A-Za-z0-9_-]+/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, '') || 'page';
  if (seenIds.has(id)) { let k = 2; while (seenIds.has(id + '-' + k)) k++; id = id + '-' + k; }
  seenIds.add(id);

  const tm = f.content.match(/<title>([\s\S]*?)<\/title>/i);
  let title = tm ? tm[1].replace(/<[^>]*>/g, '').trim() : '';
  title = (title.split(/\s*[·|]\s*|\s+—\s+|\s+-\s+/)[0] || '').trim() || base;

  return { id, title, core: i === 0, html: f.content, _num: numKey(f.name) === Infinity ? i + 1 : numKey(f.name) };
});

/* ---------------- 推导 flows[]（--infer-flows） ---------------- */
const flows = [];
const warnings = [];
if (flags.inferFlows) {
  const numToId = {};
  pages.forEach(p => { if (numToId[p._num] == null) numToId[p._num] = p.id; });

  const seenFlow = new Set();
  pages.forEach(p => {
    // 抓取含跨页意图的完整引号串作为触发描述，支持两种写法：
    //   「跳转到 P2 任务中心 · ...」 / 「查看成员信息 → P3」 / 「... -> P4 ...」
    const re = /(['"`])([^'"`\n]{0,80}?(?:跳转到\s*P\s*(\d+)|(?:→|->)\s*P\s*(\d+))[^'"`\n]{0,80}?)\1/g;
    const hits = [];
    let m;
    while ((m = re.exec(p.html)) !== null) hits.push({ trigger: m[2].trim().replace(/\\+$/, ''), to: parseInt(m[3] || m[4], 10) });
    if (!hits.length) {
      const re2 = /(?:跳转到|→|->)\s*P\s*(\d+)/g;
      while ((m = re2.exec(p.html)) !== null) hits.push({ trigger: '跳转到 P' + m[1], to: parseInt(m[1], 10) });
    }
    hits.forEach(hit => {
      const toId = numToId[hit.to];
      if (!toId) { warnings.push('⚠️  ' + p.id + ' 引用了未知页码 P' + hit.to + '（目录中无对应页面，已跳过）'); return; }
      if (toId === p.id) return; // 自跳转无意义
      const key = p.id + '>|<' + toId; // 同一对页面只保留首个触发描述，避免重复边 id
      if (seenFlow.has(key)) return;
      seenFlow.add(key);
      flows.push({ from: p.id, to: toId, trigger: hit.trigger, main: false });
    });
  });
}

/* ---------------- 组装与输出 ---------------- */
const input = {
  meta: {
    title: flags.title || path.basename(path.resolve(dir)),
    ...(flags.prdId ? { prdId: flags.prdId } : {}),
    logo: flags.logo || '▦',
  },
  pages: pages.map(({ _num, ...p }) => p),
  flows,
};

const json = JSON.stringify(input, null, 2);
if (toStdout) {
  process.stdout.write(json);
} else {
  fs.writeFileSync(outArg, json);
}

warnings.forEach(w => log(w));
log('✅ 草稿已生成: ' + (toStdout ? '<stdout>' : outArg));
log('   页面 ' + pages.length + ' 个（按文件名数字排序，首个标记 core）' +
  (flags.inferFlows ? ' · 推导流转 ' + flows.length + ' 条' : ''));
log('');
log('下一步：');
if (flags.inferFlows) {
  log('  ① 人工核对 flows[]：主路径改 main:true 并按操作先后排序，跨页长连线加 via:"bottom"');
} else {
  log('  ① 补全 flows[]（可加 --infer-flows 自动推导跨页跳转草稿）');
}
log('  ② node ' + path.join(__dirname, 'inject.js') + ' ' + (toStdout ? 'input.json' : outArg) + ' <输出目录>/<需求名>-页面流转画布.html');
log('   （page-flow-canvas@' + VERSION + '）');
