#!/usr/bin/env node
/**
 * inject.js — 将页面数据注入画布模板，产出可交付的单文件 HTML
 *
 * 用法：node inject.js <input.json|-> <output.html|->    （- 表示 stdin / stdout）
 *
 * input.json 结构见 SKILL.md「输入契约」或 examples/example-input.json
 */
'use strict';
const fs = require('fs');
const path = require('path');

const VERSION = '1.3.5';

let [,, inputFile, outputFile] = process.argv;
if (inputFile === '--stdin') inputFile = '-';
if (!inputFile || !outputFile) {
  console.error('用法: node inject.js <input.json|-> <output.html|->    （- 表示 stdin / stdout）');
  process.exit(1);
}
const toStdout = outputFile === '-';
const log = (...a) => (toStdout ? process.stderr.write(a.join(' ') + '\n') : console.log(...a));

/* ---------------- 读取与校验 ---------------- */
let input;
try {
  const raw = inputFile === '-' ? fs.readFileSync(0, 'utf8') : fs.readFileSync(inputFile, 'utf8');
  input = JSON.parse(raw);
} catch (e) {
  console.error('❌ input 读取/解析失败: ' + e.message);
  process.exit(1);
}

function validate(input) {
  const errs = [], warns = [];
  if (!input || typeof input !== 'object') return { errs: ['input 必须是 JSON 对象'], warns };
  if (!Array.isArray(input.pages) || !input.pages.length) errs.push('pages 必须是非空数组');
  if (!Array.isArray(input.flows)) errs.push('flows 必须是数组（无流转可为空数组）');
  if (errs.length) return { errs, warns };

  const ids = new Set();
  input.pages.forEach((p, i) => {
    if (!p.id || !/^[A-Za-z0-9_-]+$/.test(p.id)) errs.push('pages[' + i + '].id 缺失或含非法字符（仅限字母/数字/_/-）');
    else if (ids.has(p.id)) errs.push('pages[' + i + '].id 重复: ' + p.id);
    ids.add(p.id);
    if (!p.title) errs.push('pages[' + i + '].title 缺失');
    if (typeof p.html !== 'string' || !/<html[\s>]|<!doctype/i.test(p.html)) {
      errs.push('pages[' + i + '].html 必须是完整 HTML 字符串（含 <html> 或 <!DOCTYPE>）');
    }
  });
  input.flows.forEach((f, i) => {
    if (!ids.has(f.from)) errs.push('flows[' + i + '].from 引用了不存在的页面: ' + f.from);
    if (!ids.has(f.to)) errs.push('flows[' + i + '].to 引用了不存在的页面: ' + f.to);
    if (f.from === f.to) errs.push('flows[' + i + '] 起点与终点相同: ' + f.from);
    if (!f.trigger) errs.push('flows[' + i + '].trigger 缺失（触发跳转的用户操作描述）');
  });
  if (input.pages.length > 1 && !input.pages.some(p => p.core)) {
    warns.push('未标记核心页（core: true），建议在主路径起点页上标记');
  }
  return { errs, warns };
}

const { errs, warns } = validate(input);
warns.forEach(w => console.warn('⚠️  ' + w));
if (errs.length) {
  console.error('❌ 输入校验未通过:');
  errs.forEach(e => console.error('  - ' + e));
  process.exit(1);
}

/* ---------------- 规整数据 ---------------- */
const meta = {
  title: (input.meta && input.meta.title) || '页面流转画布',
  sub: (input.meta && input.meta.sub)
    || (input.meta && input.meta.prdId
      ? '需求 ' + input.meta.prdId + ' · ' + input.pages.length + ' 个页面 · 交付总览视图'
      : input.pages.length + ' 个页面 · 交付总览视图'),
  logo: (input.meta && input.meta.logo) || '▦',
};
// v1.3：自由便签透传（画布编辑产物 round-trip）
if (input.meta && Array.isArray(input.meta.notes) && input.meta.notes.length) {
  meta.notes = input.meta.notes;
}

const pages = input.pages.map(p => ({
  id: p.id,
  title: p.title,
  core: !!p.core,
  html: p.html,
  // v1.3：钉位坐标透传（画布内拖动节点后导出的位置）
  ...(typeof p.x === 'number' && typeof p.y === 'number' ? { x: p.x, y: p.y } : {}),
}));

const flows = input.flows.map(f => {
  const e = {
    id: f.id || ('e-' + f.from + '-' + f.to),
    source: f.from,
    target: f.to,
    label: f.trigger,
    main: f.main !== false, // 默认主路径
    // v1.3：via / note 透传，支持画布内编辑后原样导出
    ...(f.via ? { via: f.via } : {}),
    ...(f.note ? { note: f.note } : {}),
  };
  // 跨越中间节点的长连线建议走底部，避免横穿其他页面
  if (f.via === 'bottom') {
    e.sourceHandle = 's-bottom';
    e.targetHandle = 't-bottom';
  }
  return e;
});

const dupEdge = new Set();
flows.forEach(e => {
  if (dupEdge.has(e.id)) {
    console.warn('⚠️  流转 id 重复: ' + e.id + '（建议显式指定唯一 id）');
  }
  dupEdge.add(e.id);
});

/* ---------------- 注入模板 ---------------- */
const tplPath = path.join(__dirname, '..', 'template', 'canvas-template.html');
const tpl = fs.readFileSync(tplPath, 'utf8');

// JSON 序列化后转义 </script>，防止页面 HTML 中的脚本闭合标签截断外层 <script>
const lit = (obj) => JSON.stringify(obj, null, 2).replace(/<\/script>/gi, '<\\/script>');

const inject = (src, key, value) => {
  const re = new RegExp('/\\*__' + key + '__\\*/[\\s\\S]*?/\\*__END__\\*/');
  if (!re.test(src)) {
    console.error('❌ 模板中未找到注入标记: /*__' + key + '__*/ ... /*__END__*/');
    process.exit(1);
  }
  return src.replace(re, '/*__' + key + '__*/ ' + lit(value) + ' /*__END__*/');
};

let out = inject(tpl, 'META', meta);
out = inject(out, 'PAGE_DEFS', pages);
out = inject(out, 'EDGE_DEFS', flows);
out = out.replace(
  /<title>[\s\S]*?<\/title>/,
  '<title>' + meta.title.replace(/[<&>]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])) + ' · 页面流转画布</title>'
);
out = out.replace(
  '<meta charset="utf-8" />',
  '<meta charset="utf-8" />\n<meta name="generator" content="page-flow-canvas@' + VERSION + '" />'
);

if (toStdout) {
  process.stdout.write(out);
} else {
  fs.mkdirSync(path.dirname(path.resolve(outputFile)), { recursive: true });
  fs.writeFileSync(outputFile, out);
}

const mainCount = flows.filter(f => f.main).length;
log('✅ 已生成: ' + (toStdout ? '<stdout>' : outputFile));
log('   页面 ' + pages.length + ' 个（核心页 ' + pages.filter(p => p.core).length + '）· 连线 ' + flows.length + ' 条（主路径 ' + mainCount + ' / 分支 ' + (flows.length - mainCount) + '）');
log('   体积 ' + (Buffer.byteLength(out) / 1024).toFixed(1) + ' KB · page-flow-canvas@' + VERSION);
